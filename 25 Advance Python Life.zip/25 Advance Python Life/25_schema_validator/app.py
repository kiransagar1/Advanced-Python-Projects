#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 25 - Declarative Data Validation Framework
=============================================================
WHAT IT DOES
    Define data models as classes with typed, validated fields - like a mini-Pydantic:

        class Student(Model):
            name = Field(str, min_len=2)
            age  = Field(int, min=16, max=80)

    Input (e.g. from a web form or JSON) is cleaned and coerced ("25" -> 25), and ALL
    problems are reported together in one ValidationError - including nested models and
    lists. Assigning an invalid value later (student.age = 5) is also rejected.

WHAT YOU LEARN
    descriptors (__get__/__set__/__set_name__), __init_subclass__, custom exceptions,
    type coercion, composition (nested models, list fields), why validation belongs at the boundary.

USAGE
    python app.py        # demo with assertions
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# json serialises error reports, re checks formats (patterns).
import json
import re

# Sentinel meaning "no value supplied" - lets None remain a legitimate value.
MISSING = object()


# Raised internally by a single field that fails validation.
class FieldError(Exception):
    pass


# Raised when a whole model (or nested part) is invalid; .errors maps field -> message.
class ValidationError(Exception):
    def __init__(self, errors: dict):
        self.errors = errors
        super().__init__(json.dumps(errors, ensure_ascii=False))


# Field is a DESCRIPTOR: a class attribute that controls reading/writing the attribute on instances.
# It holds the rules: type, required, default, min/max, length limits, regex pattern and choices.
class Field:
    """A validated attribute. `type` can be str, int, float, bool or another Model subclass."""

    def __init__(self, type=str, *, required=True, default=MISSING, min=None, max=None,
                 min_len=None, max_len=None, pattern=None, choices=None):
        self.type, self.required, self.default = type, required, default
        self.min, self.max, self.min_len, self.max_len = min, max, min_len, max_len
        # Compile the regex once.
        self.pattern = re.compile(pattern) if pattern else None
        self.choices, self.name = choices, "?"

    # Python calls __set_name__ automatically, so the field learns its own attribute name (e.g. "age").
    def __set_name__(self, owner, name):
        self.name = name

    # --- descriptor protocol: values live in the instance __dict__ ---
    # Reading: return the stored value from the instance, or the Field itself when accessed on the class.
    def __get__(self, obj, owner=None):
        return self if obj is None else obj.__dict__.get(self.name)

    # Writing: validate before storing, so an invalid assignment leaves the old value intact.
    def __set__(self, obj, value):
        try:
            obj.__dict__[self.name] = self.clean(value)
        except FieldError as e:
            raise ValidationError({self.name: str(e)}) from None

    # Convert the raw input to the field's type ("25" -> 25) or fail.
    def coerce(self, v):
        t = self.type
        # A nested Model: accept an existing instance or build one from a dict.
        if isinstance(t, type) and issubclass(t, Model):
            return v if isinstance(v, t) else t(**v) if isinstance(v, dict) else self._fail("must be an object")
        # Booleans accept true/false, yes/no and 1/0 (any case).
        if t is bool:
            if isinstance(v, bool): return v
            if str(v).lower() in ("true", "yes", "1"): return True
            if str(v).lower() in ("false", "no", "0"): return False
            self._fail("must be true or false")
        # Integers: reject True/False (bool is an int subclass), accept digit strings, reject everything else.
        if t is int:
            if isinstance(v, bool): self._fail("must be an integer")
            if isinstance(v, int): return v
            if isinstance(v, str) and re.fullmatch(r"\s*-?\d+\s*", v): return int(v)
            self._fail("must be an integer")
        # Floats: reject booleans, accept anything float() understands.
        if t is float:
            try:
                if isinstance(v, bool): raise ValueError
                return float(v)
            except (TypeError, ValueError):
                self._fail("must be a number")
        # Strings: must be text; surrounding spaces are stripped.
        if t is str:
            if not isinstance(v, str): self._fail("must be text")
            return v.strip()
        return v

    def _fail(self, msg):
        raise FieldError(msg)

    # Apply all rules to one value. None means "not provided" and is an error only when the field is required.
    def clean(self, value):
        if value is None:
            if self.required:
                raise FieldError("is required")
            return None
        # Coerce first, then check each constraint.
        v = self.coerce(value)
        if self.min is not None and v < self.min: raise FieldError(f"must be >= {self.min}")
        if self.max is not None and v > self.max: raise FieldError(f"must be <= {self.max}")
        if self.min_len is not None and len(v) < self.min_len: raise FieldError(f"length must be >= {self.min_len}")
        if self.max_len is not None and len(v) > self.max_len: raise FieldError(f"length must be <= {self.max_len}")
        if self.pattern and not self.pattern.fullmatch(v): raise FieldError("has an invalid format")
        if self.choices is not None and v not in self.choices: raise FieldError(f"must be one of {list(self.choices)}")
        return v


# A field holding a list of items, each validated by the `item` field.
class ListField(Field):
    def __init__(self, item: Field, **kw):
        super().__init__(list, **kw)
        self.item = item

    def clean(self, value):
        if value is None:
            if self.required: raise FieldError("is required")
            return None
        if not isinstance(value, list): raise FieldError("must be a list")
        if self.min_len is not None and len(value) < self.min_len: raise FieldError(f"needs at least {self.min_len} item(s)")
        if self.max_len is not None and len(value) > self.max_len: raise FieldError(f"allows at most {self.max_len} item(s)")
        # Validate every element and collect the problems by position: {"[0]": "message"}.
        out, problems = [], {}
        for i, v in enumerate(value):
            try:
                out.append(self.item.clean(v))
            except FieldError as e:
                problems[f"[{i}]"] = str(e)
        if problems:
            raise ValidationError(problems)
        return out


# Base class for data models (a mini-Pydantic).
class Model:
    _fields: dict = {}

    # __init_subclass__ runs whenever a subclass is defined: it collects its Field attributes (and inherited ones) into _fields.
    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        fields = {}
        # Start with fields inherited from parent classes, then add this class's own.
        for base in reversed(cls.__mro__[1:]):
            fields.update(getattr(base, "_fields", {}))
        fields.update({k: v for k, v in vars(cls).items() if isinstance(v, Field)})
        cls._fields = fields

    # Build an instance from keyword arguments, validating every field and collecting ALL errors at once.
    def __init__(self, **data):
        # Unknown keyword arguments are errors too.
        errors = {k: "unknown field" for k in data if k not in self._fields}
        for name, field in self._fields.items():
            value = data.get(name, MISSING)
            # Not supplied: use the default (call it when it is a factory such as list), otherwise None.
            if value is MISSING:
                if field.default is not MISSING:
                    value = field.default() if callable(field.default) else field.default
                else:
                    value = None
            try:
                self.__dict__[name] = field.clean(value)
            except FieldError as e:
                errors[name] = str(e)
            # Problems inside a nested model or list are kept as a nested error structure.
            except ValidationError as e:                       # nested model / list item problems
                errors[name] = e.errors
        # Raise one ValidationError describing every problem together.
        if errors:
            raise ValidationError(errors)

    # Convert back to plain dicts/lists (nested models included), ready for json.dumps.
    def to_dict(self) -> dict:
        def conv(v):
            return v.to_dict() if isinstance(v, Model) else [conv(x) for x in v] if isinstance(v, list) else v
        return {k: conv(self.__dict__[k]) for k in self._fields}

    # Build a model directly from a JSON string.
    @classmethod
    def from_json(cls, text: str):
        return cls(**json.loads(text))


# Example models: Address nested inside Student.
class Address(Model):
    city = Field(str, min_len=2)
    pin = Field(str, pattern=r"\d{6}")


class Student(Model):
    name = Field(str, min_len=2, max_len=50)
    age = Field(int, min=16, max=80)
    email = Field(str, pattern=r"[^@\s]+@[^@\s]+\.\w+")
    course = Field(str, choices=["Python", "Oracle SQL", "Java"])
    phone = Field(str, required=False, pattern=r"[6-9]\d{9}")
    address = Field(Address)
    skills = ListField(Field(str, min_len=2), required=False, default=list, max_len=5)


# Demo with assertions.
def demo() -> None:
    # Valid data with messy input: spaces are trimmed and the age string "25" becomes the integer 25.
    s = Student(name="  Ravi Kumar ", age="25", email="ravi@example.com", course="Python",
                address={"city": "Hyderabad", "pin": "500001"}, skills=["SQL", "HTML"])
    # Check the conversions and the nested Address object.
    assert s.name == "Ravi Kumar" and s.age == 25 and isinstance(s.age, int)
    assert s.address.city == "Hyderabad" and s.phone is None
    # Round trip: model -> dict -> JSON -> model gives identical data.
    assert Student.from_json(json.dumps(s.to_dict())).to_dict() == s.to_dict()          # JSON round trip
    assert Student(name="Sita", age=30, email="s@x.io", course="Java", address=Address(city="Vizag", pin="530001")).skills == []

    # Deliberately invalid data: every problem must be reported together, not just the first.
    try:
        Student(name="R", age=12, email="nope", course="C++", skills=["a", "SQL"], oops=1,
                address={"city": "H", "pin": "12"})
        raise AssertionError("must fail")
    except ValidationError as e:
        print("errors:", json.dumps(e.errors, indent=2, ensure_ascii=False))
        er = e.errors
        # Exactly these fields are reported.
        assert set(er) == {"name", "age", "email", "course", "skills", "oops", "address"}
        # Nested errors have their own structure.
        assert er["address"] == {"city": "length must be >= 2", "pin": "has an invalid format"}
        assert er["skills"] == {"[0]": "length must be >= 2"} and er["oops"] == "unknown field"

    # Assignments are validated too: "30" converts to 30.
    s.age = "30"
    assert s.age == 30
    try:
        # A bad assignment (5 is below the minimum 16) is rejected and the old value is kept.
        s.age = 5; raise AssertionError
    except ValidationError as e:
        assert e.errors == {"age": "must be >= 16"} and s.age == 30                       # unchanged after a bad assignment
    # True, "abc" and 25.5 are all invalid ages.
    for bad_age in (True, "abc", 25.5):
        try:
            s.age = bad_age; raise AssertionError(bad_age)
        except ValidationError:
            pass
    print("PythonLife validation framework demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo()
