#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 17 - Safe Expression Engine (Pratt Parser Calculator)
========================================================================
WHAT IT DOES
    A scientific calculator with variables ("x = 5"), functions (sqrt, sin, max...),
    constants (pi, e), correct operator precedence (-2**2 = -4, 2**3**2 = 512),
    and clear error messages. It NEVER uses eval(), so it is safe to expose to users.

WHAT YOU LEARN
    tokenising, Pratt (top-down operator precedence) parsing, building and walking
    an AST, custom exceptions, why eval() is dangerous. This is how real interpreters start.

USAGE
    python app.py          # demo with assertions
    python app.py --repl   # interactive calculator
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# math supplies the functions/constants and re tokenises input. No eval() anywhere.
import math
import re
import sys

# Token pattern: a number (group 1), an identifier (group 2) or an operator/bracket (group 3).
TOKEN = re.compile(r"\s*(?:(\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)|([A-Za-z_]\w*)|(\*\*|[-+*/%(),=]))")
# Binary operators: (binding power, associativity). Higher binds tighter; "right" groups right-to-left (2**3**2 = 2**(3**2)).
BINARY = {"=": (1, "right"), "+": (10, "left"), "-": (10, "left"), "*": (20, "left"),
          "/": (20, "left"), "%": (20, "left"), "**": (30, "right")}
# Unary minus binds tighter than * and / but looser than **, so -2**2 = -(2**2) = -4.
UNARY_PREC = 25   # above * / but below ** so that -2**2 == -(2**2)
# Whitelist of callable functions: users can only call names listed here.
FUNCS = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan, "log": math.log, "exp": math.exp,
         "abs": abs, "round": round, "min": min, "max": max, "floor": math.floor, "ceil": math.ceil}
# Built-in constants.
CONSTS = {"pi": math.pi, "e": math.e}


# Every user-facing error is a CalcError, so callers need only one except clause.
class CalcError(Exception):
    """Any user-facing problem: syntax, unknown name, math domain error."""


# Lexer: turn text into a list of (kind, value) tokens.
def tokenize(src: str) -> list:
    pos, toks = 0, []
    while pos < len(src):
        # Only trailing whitespace is left: stop.
        if src[pos:].isspace():
            break
        m = TOKEN.match(src, pos)
        if not m:
            # No pattern matched: report the first bad character.
            raise CalcError(f"unexpected character {src[pos:].strip()[0]!r}")
        num, name, op = m.groups()
        if num is not None:
            # Numbers with . or e become float, others int.
            toks.append(("num", float(num) if re.search(r"[.eE]", num) else int(num)))
        elif name is not None:
            toks.append(("id", name))
        else:
            toks.append(("op", op))
        pos = m.end()
    # End-of-input marker so the parser never runs off the list.
    toks.append(("end", None))
    return toks


# Pratt parser: builds a syntax tree from the tokens using binding powers.
class Parser:
    def __init__(self, toks: list):
        self.toks, self.i = toks, 0

    # Look at the current token without consuming it.
    def peek(self):
        return self.toks[self.i]

    # Consume and return the current token.
    def next(self):
        t = self.toks[self.i]
        self.i += 1
        return t

    # Consume a specific operator or raise an error.
    def expect(self, op: str):
        if self.next() != ("op", op):
            raise CalcError(f"expected {op!r}")

    # Parse a full expression and make sure nothing is left over.
    def parse(self):
        node = self.expr(0)
        if self.peek()[0] != "end":
            raise CalcError(f"unexpected {self.peek()[1]!r}")
        return node

    # Core of the Pratt algorithm: keep extending `left` while the next operator binds tighter than rbp.
    def expr(self, rbp: int):
        left = self.nud(self.next())
        while True:
            kind, val = self.peek()
            # Stop when the next token is not a binary operator or binds too weakly.
            if kind != "op" or val not in BINARY or BINARY[val][0] <= rbp:
                return left
            prec, assoc = BINARY[val]
            self.next()
            # Right-associative operators recurse with a slightly lower power so they group to the right.
            right = self.expr(prec - 1 if assoc == "right" else prec)
            # Assignment is only allowed when the left side is a plain variable name.
            if val == "=":
                if left[0] != "var":
                    raise CalcError("can only assign to a variable name")
                left = ("assign", left[1], right)
            else:
                left = ("bin", val, left, right)

    # nud = "null denotation": how a token behaves at the START of an expression (number, name, call, bracket, unary sign).
    def nud(self, tok):
        kind, val = tok
        if kind == "num":
            return ("num", val)
        # Identifier: a function call if followed by ( ... ), otherwise a variable.
        if kind == "id":
            if self.peek() == ("op", "("):
                self.next(); args = []
                if self.peek() != ("op", ")"):
                    args.append(self.expr(0))
                    while self.peek() == ("op", ","):
                        self.next(); args.append(self.expr(0))
                self.expect(")")
                return ("call", val, args)
            return ("var", val)
        # Parenthesised sub-expression.
        if (kind, val) == ("op", "("):
            node = self.expr(0); self.expect(")"); return node
        # Unary minus.
        if (kind, val) == ("op", "-"):
            return ("neg", self.expr(UNARY_PREC))
        if (kind, val) == ("op", "+"):
            return self.expr(UNARY_PREC)
        # Anything else is a syntax error with a helpful message.
        raise CalcError("unexpected end of expression" if kind == "end" else f"unexpected {val!r}")


# Evaluates syntax trees and stores variables between calculations.
class Calculator:
    def __init__(self):
        self.vars: dict = {}

    def run(self, src: str):
        # Tokenise, parse, evaluate, and remember the result as "ans".
        result = self.eval(Parser(tokenize(src)).parse())
        self.vars["ans"] = result
        return result

    # Walk the syntax tree recursively and compute its value.
    def eval(self, n):
        t = n[0]
        if t == "num":
            return n[1]
        if t == "var":
            # Variable lookup: user variables first, then constants.
            if n[1] in self.vars: return self.vars[n[1]]
            if n[1] in CONSTS: return CONSTS[n[1]]
            raise CalcError(f"unknown variable {n[1]!r}")
        if t == "neg":
            return -self.eval(n[1])
        # Assignment: constants and function names cannot be overwritten.
        if t == "assign":
            if n[1] in CONSTS or n[1] in FUNCS:
                raise CalcError(f"{n[1]!r} is reserved")
            self.vars[n[1]] = self.eval(n[2])
            return self.vars[n[1]]
        if t == "call":
            # Only whitelisted functions may be called; math errors become CalcError.
            if n[1] not in FUNCS:
                raise CalcError(f"unknown function {n[1]!r}")
            try:
                return FUNCS[n[1]](*[self.eval(a) for a in n[2]])
            except (ValueError, TypeError, OverflowError) as e:
                raise CalcError(f"{n[1]}(): {e}") from None
        # Remaining case: a binary operation.
        _, op, l, r = n
        a, b = self.eval(l), self.eval(r)
        try:
            if op == "+": return a + b
            if op == "-": return a - b
            if op == "*": return a * b
            if op == "/": return a / b
            if op == "%": return a % b
            # Safety limit: huge integer exponents (e.g. 2 ** 100000) would freeze the machine.
            if isinstance(b, int) and abs(b) > 4000:
                raise CalcError("exponent too large")
            return a ** b
        except ZeroDivisionError:
            raise CalcError("division by zero") from None
        except OverflowError:
            raise CalcError("number too large") from None


# Demo with assertions.
def demo() -> None:
    c = Calculator()
    # Table of (expression, expected value): precedence, associativity, variables, functions, floats.
    cases = [("1 + 2 * 3", 7), ("(1 + 2) * 3", 9), ("-2 ** 2", -4), ("2 ** 3 ** 2", 512), ("10 % 4", 2),
             ("2 ** -1", 0.5), ("sqrt(16) + max(1, 2, 3)", 7), ("x = 5", 5), ("x * 2 + 1", 11), ("ans + 1", 12),
             ("y = x = 3", 3), ("x + y", 6), ("round(pi, 2)", 3.14), ("10 / 4", 2.5), ("1e3 + .5", 1000.5)]
    for src, want in cases:
        got = c.run(src)
        assert got == want, (src, got, want)
        print(f"{src:<26} = {got}")
    # Table of (bad input, expected message): each must raise CalcError, including code-injection attempts such as __import__('os').
    for bad, msg in [("1 / 0", "division by zero"), ("foo(1)", "unknown function"), ("2 +", "unexpected end"),
                     ("(1 + 2", "expected ')'"), ("zzz", "unknown variable"), ("2 ** 100000", "exponent too large"),
                     ("3 = 4", "can only assign"), ("pi = 3", "reserved"), ("sqrt(-1)", "sqrt()"), ("5 $ 2", "unexpected character"),
                     ("__import__('os')", "unexpected")]:
        try:
            c.run(bad)
            raise AssertionError(f"{bad!r} should fail")
        except CalcError as e:
            assert msg in str(e), (bad, str(e))
    print("PythonLife expression engine demo OK")


# Interactive calculator: type expressions, "quit" to exit.
def repl() -> None:
    c = Calculator()
    while (line := input("calc> ").strip()) not in ("quit", "exit"):
        try:
            print(c.run(line))
        except CalcError as e:
            print("error:", e)


# Run the REPL with --repl, otherwise the demo.
if __name__ == "__main__":
    repl() if "--repl" in sys.argv else demo()
