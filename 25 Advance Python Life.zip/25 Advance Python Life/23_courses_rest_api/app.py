#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 23 - Course Catalogue REST API (standard library only)
=========================================================================
WHAT IT DOES
    A complete JSON REST API for a course catalogue built on http.server:
        GET    /health
        GET    /courses?mode=live&limit=10&offset=0   (filter + pagination)
        POST   /courses                               (needs X-API-Key)
        GET    /courses/<id>
        PUT    /courses/<id>                          (needs X-API-Key)
        DELETE /courses/<id>                          (needs X-API-Key)
    Proper status codes (201, 204, 400, 401, 404, 405, 413), input validation with
    helpful error lists, thread-safe storage, and a self-test client.

WHAT YOU LEARN
    HTTP fundamentals, REST design, routing by hand, JSON validation, ThreadingHTTPServer,
    constant-time key comparison, testing a live server with urllib.

USAGE
    python app.py              # starts a temporary server, runs the tests, exits
    python app.py --serve      # run on http://127.0.0.1:8000 (API key: pythonlife-demo-key)
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# hmac for safe key comparison, json for request/response bodies, http.server for the web server, urllib for the demo client.
import hmac
import json
import sys
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# Demo API key. In real use load it from an environment variable or a secrets manager - never hard-code it.
API_KEY = "pythonlife-demo-key"
# Reject request bodies larger than 64 KB.
MAX_BODY = 64 * 1024
# Allowed values for the "mode" field.
MODES = {"live", "recorded"}


# In-memory data store: a dict of courses, an id counter and a lock for thread safety.
class Store:
    def __init__(self):
        # ThreadingHTTPServer handles requests in several threads, so changes happen under a lock.
        self.lock, self.items, self.next_id = threading.Lock(), {}, 1
        # Start with two sample courses.
        for title, fee, mode in (("Python Full Course", 10000, "live"), ("Oracle SQL & PL/SQL", 8000, "recorded")):
            self.create({"title": title, "fee": fee, "mode": mode})

    def create(self, d):
        with self.lock:
            item = {"id": self.next_id, **d}
            self.items[self.next_id] = item
            self.next_id += 1
            return item


# Validate a course payload and return a list of error messages (empty list = valid).
# partial=True would validate only the fields that are present.
def validate(d, partial: bool = False) -> list:
    errors = []
    if not isinstance(d, dict):
        return ["body must be a JSON object"]
    if not partial or "title" in d:
        if not isinstance(d.get("title"), str) or not d["title"].strip():
            errors.append("title: required non-empty string")
    if not partial or "fee" in d:
        # bool is a subclass of int in Python, so True/False are rejected explicitly as fees.
        if isinstance(d.get("fee"), bool) or not isinstance(d.get("fee"), (int, float)) or d["fee"] < 0:
            errors.append("fee: required number >= 0")
    if not partial or "mode" in d:
        if d.get("mode") not in MODES:
            errors.append(f"mode: must be one of {sorted(MODES)}")
    # Reject unknown fields instead of silently ignoring them.
    errors += [f"{k}: unknown field" for k in d if k not in {"title", "fee", "mode"}]
    return errors


# Request handler: one instance per HTTP request.
class Handler(BaseHTTPRequestHandler):
    server_version = "PythonLifeAPI/1.0"

    # Silence the default per-request console logging.
    def log_message(self, *a):
        pass

    # Send a JSON response with the right status code and headers.
    def send_json(self, code, obj=None, headers=None):
        data = b"" if obj is None else json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        # Optional extra headers (for example Location).
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    # Check the X-API-Key header; compare_digest compares in constant time to avoid timing attacks.
    def authorized(self) -> bool:
        return hmac.compare_digest(self.headers.get("X-API-Key", ""), self.server.api_key)

    # Read and parse the JSON body, answering 413/400 itself when it is too big or invalid.
    def read_json(self):
        # The body was already read (drained) in route(); parse the saved bytes here.
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            self.send_json(413, {"error": "body too large"}); return None
        try:
            return json.loads(self._body or b"null")
        except json.JSONDecodeError:
            self.send_json(400, {"error": "invalid JSON"}); return None

    # Single router for all HTTP methods:
    #   GET /health, GET/POST /courses, GET/PUT/DELETE /courses/<id>.
    def route(self, method: str):
        # Always consume the request body first. Answering 401/404/405 while the client's body is still
        # unread makes Windows reset the connection (client sees ConnectionResetError / WinError 10054).
        n = int(self.headers.get("Content-Length") or 0)
        self._body = self.rfile.read(n) if 0 < n <= MAX_BODY else b""
        u = urlparse(self.path)
        parts, q, store = [p for p in u.path.split("/") if p], parse_qs(urlparse(self.path).query), self.server.store
        # Split the path into parts and parse the query string (?mode=live&limit=10).
        if parts == ["health"] and method == "GET":
            return self.send_json(200, {"status": "ok"})
        if not parts or parts[0] != "courses" or len(parts) > 2:
            return self.send_json(404, {"error": "not found"})
        # Reads are public; every write (POST/PUT/DELETE) needs the API key.
        if method != "GET" and not self.authorized():
            return self.send_json(401, {"error": "missing or invalid API key"})
        # Collection endpoint: /courses
        if len(parts) == 1:
            if method == "GET":
                items = sorted(store.items.values(), key=lambda c: c["id"])
                # Optional filter: ?mode=live or ?mode=recorded.
                if "mode" in q:
                    items = [c for c in items if c["mode"] == q["mode"][0]]
                try:
                    # Pagination: limit and offset must be integers.
                    limit, offset = int(q.get("limit", ["50"])[0]), int(q.get("offset", ["0"])[0])
                except ValueError:
                    return self.send_json(400, {"error": "limit/offset must be integers"})
                # Return the total count plus the requested slice (the max() prevents a negative limit).
                return self.send_json(200, {"total": len(items), "items": items[offset:offset + max(limit, 0)]})
            # Create a new course.
            if method == "POST":
                body = self.read_json()
                if body is None and self.wfile.closed: return
                errs = validate(body)
                if errs: return self.send_json(400, {"errors": errs})
                item = store.create(body)
                return self.send_json(201, item, {"Location": f"/courses/{item['id']}"})
            return self.send_json(405, {"error": "method not allowed"})
        # Item endpoints: /courses/<id> (non-numeric ids are simply not found).
        if not parts[1].isdigit():
            return self.send_json(404, {"error": "not found"})
        cid = int(parts[1])
        # Look the id up under the lock.
        with store.lock:
            exists = cid in store.items
        if not exists:
            return self.send_json(404, {"error": f"course {cid} not found"})
        # Read one course.
        if method == "GET":
            return self.send_json(200, store.items[cid])
        # Replace a course completely (PUT = full update, so the whole body is validated).
        if method == "PUT":
            body = self.read_json()
            errs = validate(body)
            if errs: return self.send_json(400, {"errors": errs})
            with store.lock:
                store.items[cid] = {"id": cid, **body}
            return self.send_json(200, store.items[cid])
        # Delete a course (204 = success, no body).
        if method == "DELETE":
            with store.lock:
                store.items.pop(cid, None)
            return self.send_json(204)
        return self.send_json(405, {"error": "method not allowed"})

    # Map each HTTP verb to the router; PATCH is deliberately unsupported (405).
    def do_GET(self): self.route("GET")
    def do_POST(self): self.route("POST")
    def do_PUT(self): self.route("PUT")
    def do_DELETE(self): self.route("DELETE")
    def do_PATCH(self):
        self.rfile.read(min(int(self.headers.get("Content-Length") or 0), MAX_BODY))   # drain body first
        self.send_json(405, {"error": "method not allowed"})


# Factory: create a server on 127.0.0.1 with its own store. Port 0 means "any free port".
def make_server(port: int = 0, api_key: str = API_KEY) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.store, srv.api_key = Store(), api_key
    return srv


# Tiny HTTP client for the demo; returns (status, parsed JSON, headers) even for error responses.
# The demo only talks to 127.0.0.1, so never route it through a system/corporate HTTP proxy
# (a configured proxy would otherwise swallow the requests and the demo would fail).
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def call(base, method, path, body=None, key=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(base + path, data=data, method=method, headers={"Content-Type": "application/json"})
    if key:
        req.add_header("X-API-Key", key)
    try:
        with OPENER.open(req, timeout=5) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None), r.headers
    except urllib.error.HTTPError as e:
        raw = e.read()
        return e.code, (json.loads(raw) if raw else None), e.headers


# Demo: start the server in a background thread and test every endpoint with assertions.
def demo() -> None:
    srv = make_server()
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    try:
        # Health check.
        assert call(base, "GET", "/health")[:2] == (200, {"status": "ok"})
        # List all courses.
        s, body, _ = call(base, "GET", "/courses"); assert s == 200 and body["total"] == 2
        s, body, _ = call(base, "GET", "/courses?mode=live"); assert [c["id"] for c in body["items"]] == [1]
        s, body, _ = call(base, "GET", "/courses?limit=1&offset=1"); assert body["items"][0]["id"] == 2
        new = {"title": "Java Full Stack", "fee": 12000, "mode": "live"}
        # Writes without a key, or with a wrong key, must be refused (401).
        assert call(base, "POST", "/courses", new)[0] == 401                                  # no key
        assert call(base, "POST", "/courses", new, key="wrong")[0] == 401                     # wrong key
        # Create with the right key -> 201 Created, with a Location header for the new course.
        s, body, h = call(base, "POST", "/courses", new, key=API_KEY)
        assert s == 201 and body["id"] == 3 and h["Location"] == "/courses/3"
        # Four invalid fields (title, fee, mode, unknown field) -> four error messages.
        s, body, _ = call(base, "POST", "/courses", {"title": "", "fee": -1, "mode": "x", "oops": 1}, key=API_KEY)
        assert s == 400 and len(body["errors"]) == 4
        # Read, update (PUT) and delete the new course.
        assert call(base, "GET", "/courses/3")[1]["title"] == "Java Full Stack"
        assert call(base, "PUT", "/courses/3", {**new, "fee": 11000}, key=API_KEY)[1]["fee"] == 11000
        assert call(base, "DELETE", "/courses/3", key=API_KEY)[0] == 204
        assert call(base, "GET", "/courses/3")[0] == 404
        # Unknown routes -> 404; unsupported verb -> 405.
        assert call(base, "GET", "/courses/abc")[0] == 404 and call(base, "GET", "/nothing")[0] == 404
        assert call(base, "PATCH", "/courses/1", {}, key=API_KEY)[0] == 405
        print("all API checks passed against", base)
    # Always shut the server down.
    finally:
        srv.shutdown()
    print("PythonLife REST API demo OK")


# --serve runs the real server on port 8000; otherwise the demo runs.
if __name__ == "__main__":
    if "--serve" in sys.argv:
        s = make_server(8000)
        print("Serving on http://127.0.0.1:8000  (Ctrl+C to stop)")
        s.serve_forever()
    else:
        demo()
