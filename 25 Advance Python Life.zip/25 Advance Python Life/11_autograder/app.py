#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 11 - Sandboxed Auto-Grader for Python Assignments
====================================================================
WHAT IT DOES
    Grades student submissions automatically. Each test case runs in its OWN
    Python subprocess (isolated mode, hard timeout, memory cap on Linux/macOS), so
    infinite loops, crashes or huge allocations cannot take down the grader.
    Output: PASS / FAIL / ERROR / TIMEOUT per test and a percentage score.

WHAT YOU LEARN
    subprocess with timeouts, process isolation, resource limits, JSON as the
    protocol between processes, importlib to load code from a file.
    NOTE: this is a teaching-grade sandbox. For untrusted code on a public server
    use containers/VMs as well.

USAGE
    python app.py                                   # demo (grades 4 sample submissions)
    python app.py student.py fib "[[0],0]" "[[10],55]"   # grade one file: func + [args, expected] cases
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# json passes data to/from the child process, subprocess runs student code in isolation, tempfile holds the submission.
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# Harness: tiny program run in a SEPARATE Python process. It imports the student's file, calls the
# requested function with the JSON arguments and prints the result after a marker line, so the
# student's own print() output cannot be mistaken for the answer.
HARNESS = r"""
import importlib.util, json, sys
path, func, args = sys.argv[1], sys.argv[2], json.loads(sys.argv[3])
spec = importlib.util.spec_from_file_location("student", path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
print("@@RESULT@@" + json.dumps(getattr(mod, func)(*args)))
"""


# Resource limits applied in the child process before it starts (Linux/macOS only).
def _limits():                                   # runs in the child before exec (POSIX only)
    import resource
    # Cap memory (address space) at 1 GB so huge allocations fail instead of freezing the machine.
    resource.setrlimit(resource.RLIMIT_AS, (1024 * 1024 * 1024,) * 2)    # 1 GB address space
    # Cap CPU time at 5 seconds.
    resource.setrlimit(resource.RLIMIT_CPU, (5, 5))


# Run ONE test case in its own process and return (status, message).
# Status is PASS, FAIL, ERROR or TIMEOUT.
def run_case(path: Path, func: str, args: list, expected, timeout: float = 1.5) -> tuple:
    try:
        # -I = isolated mode (ignores environment variables and the user's site-packages); -c runs the harness text.
        p = subprocess.run([sys.executable, "-I", "-c", HARNESS, str(path), func, json.dumps(args)],
                           capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace",     # never crash on odd bytes (Windows code pages)
                           # preexec_fn installs the limits on POSIX systems; Windows has no resource module.
                           preexec_fn=_limits if os.name == "posix" else None)
    # Infinite loop: subprocess.run kills the child after `timeout` seconds.
    except subprocess.TimeoutExpired:
        return "TIMEOUT", f"exceeded {timeout}s"
    # Non-zero exit code = the student's code crashed; show the last traceback line.
    if p.returncode != 0:
        last = (p.stderr.strip().splitlines() or ["crashed"])[-1]
        return "ERROR", last
    # Find our marker line in the output (ignores anything else the student printed).
    marker = [l for l in p.stdout.splitlines() if l.startswith("@@RESULT@@")]
    if not marker:
        return "ERROR", "no result"
    got = json.loads(marker[-1][len("@@RESULT@@"):])
    # Compare the returned value with the expected one.
    return ("PASS", "") if got == expected else ("FAIL", f"got {got!r}, expected {expected!r}")


# Grade a whole submission against all test cases and return a percentage score.
def grade(source: str, func: str, cases: list, timeout: float = 1.5) -> dict:
    # The code is written to a temporary folder that disappears afterwards.
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "student_code.py"
        path.write_text(source, encoding="utf-8")
        results, skip = [], False
        for args, expected in cases:
            # After one TIMEOUT the remaining cases are skipped, so an infinite loop wastes time only once.
            if skip:
                results.append(("SKIPPED", "earlier timeout")); continue
            r = run_case(path, func, args, expected, timeout)
            results.append(r)
            skip = r[0] == "TIMEOUT"          # don't waste time repeating an infinite loop
    passed = sum(1 for s, _ in results if s == "PASS")
    return {"results": results, "score": round(100 * passed / len(cases))}


# Test cases for fib(n): ([arguments], expected result).
FIB_CASES = [([0], 0), ([1], 1), ([10], 55), ([20], 6765)]
# Four simulated student submissions: correct, off-by-one, infinite loop and crash.
SUBMISSIONS = {
    "ravi (correct)": "def fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n",
    "sita (off by one)": "def fib(n):\n    a, b = 1, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n",
    "anil (infinite loop)": "def fib(n):\n    while True:\n        pass\n",
    "kiran (crash)": "def fib(n):\n    return 1 / 0\n",
}


# Demo with assertions.
def demo() -> None:
    out = {}
    for name, src in SUBMISSIONS.items():
        out[name] = grade(src, "fib", FIB_CASES)
        print(f"{name:<22} score={out[name]['score']:>3}%  {[s for s, _ in out[name]['results']]}")
    # The correct solution scores 100%.
    assert out["ravi (correct)"]["score"] == 100
    # The off-by-one solution passes only fib(1) -> 1 of 4 = 25%.
    assert out["sita (off by one)"]["score"] == 25      # only fib(1) happens to match
    # The infinite loop is stopped by the timeout and later cases are skipped.
    assert out["anil (infinite loop)"]["results"][0][0] == "TIMEOUT"
    assert out["anil (infinite loop)"]["results"][1][0] == "SKIPPED"
    # The crash is reported as ERROR with the exception message.
    assert out["kiran (crash)"]["results"][0] == ("ERROR", "ZeroDivisionError: division by zero")
    print("PythonLife auto-grader demo OK")


# CLI: python app.py <file.py> <function> <case-json> ... ; no arguments runs the demo.
if __name__ == "__main__":
    if len(sys.argv) > 3:
        cases = [json.loads(c) for c in sys.argv[3:]]
        res = grade(Path(sys.argv[1]).read_text(encoding="utf-8"), sys.argv[2], cases)
        print(res)
    else:
        demo()
