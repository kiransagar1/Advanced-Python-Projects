#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 03 - Adaptive Quiz Engine
============================================
WHAT IT DOES
    A quiz that adapts to the learner. Two correct answers in a row move the
    learner to harder questions; a wrong answer moves them down. At the end
    you get a score (harder questions are worth more) and the list of topics
    that need revision.

WHAT YOU LEARN
    dataclasses, state machines, random.Random(seed) for reproducible tests,
    separating engine logic from the user interface.

USAGE
    python app.py            # simulated learner demo (deterministic, with assertions)
    python app.py --play     # take the quiz yourself in the terminal
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# random.Random(seed) gives reproducible quizzes for testing; defaultdict counts missed topics.
import random
import sys
from collections import defaultdict
from dataclasses import dataclass, field


# frozen=True makes Question immutable and hashable, so it can be compared and stored in lists/sets safely.
@dataclass(frozen=True)
class Question:
    text: str
    options: tuple
    answer: int          # index into options
    level: int           # 1 easy .. 3 hard
    topic: str


# Question bank. Each entry: text, options, index of the correct option, level (1-3), topic.
BANK = [
    Question("What is type(5 / 2) in Python 3?", ("int", "float", "double", "str"), 1, 1, "numbers"),
    Question("Which keyword defines a function?", ("func", "define", "def", "lambda only"), 2, 1, "functions"),
    Question("Which of these is immutable?", ("list", "dict", "set", "tuple"), 3, 1, "data types"),
    Question("What does [1, 2, 3][-1] return?", ("1", "3", "error", "[3]"), 1, 2, "lists"),
    Question("What is bool([])?", ("True", "False", "None", "error"), 1, 2, "truthiness"),
    Question("d = {}; d.get('k') returns...", ("KeyError", "0", "None", "''"), 2, 2, "dicts"),
    Question("Which creates squares of 0,1,2?", ("[x*x for x in range(3)]", "[x**x in range(3)]", "(x*x) for 3", "range(3)**2"), 0, 2, "comprehensions"),
    Question("What is the output of 'abc'[::-1]?", ("abc", "cba", "bca", "error"), 1, 2, "strings"),
    Question("def f(a, b=[]): b.append(a); return b -- what is the gotcha?", ("b is copied each call", "b is shared between calls", "syntax error", "b is a tuple"), 1, 3, "functions"),
    Question("What does functools.lru_cache do?", ("compiles code", "memoizes results", "locks threads", "logs calls"), 1, 3, "decorators"),
    Question("'a is b' checks...", ("equal values", "same object identity", "same type", "same length"), 1, 3, "identity"),
    Question("A function using 'yield' returns...", ("a list", "a generator", "None", "a tuple"), 1, 3, "generators"),
]


# Session holds all quiz state (current level, streak, score, history).
# It contains pure logic with no print/input, so it is easy to unit-test.
@dataclass
class Session:
    """Holds quiz state. Pure logic - no printing, so it is easy to test."""
    bank: list
    length: int = 8
    # default_factory gives every Session its own RNG / list / dict (never share mutable defaults).
    rng: random.Random = field(default_factory=random.Random)
    # Everyone starts at the middle difficulty.
    level: int = 2
    # streak = consecutive correct answers at the current level.
    streak: int = 0
    score: int = 0
    asked: list = field(default_factory=list)
    topic_miss: dict = field(default_factory=lambda: defaultdict(int))

    # Pick the next question, or None when the quiz is over.
    def next_question(self):
        # Stop after the configured number of questions.
        if len(self.asked) >= self.length:
            return None
        # Never repeat a question that was already asked.
        unseen = [q for q in self.bank if q not in self.asked]
        if not unseen:
            return None
        # Prefer the current level; if none is left, use the closest level available.
        # prefer the current level; otherwise the nearest available level
        best = min(abs(q.level - self.level) for q in unseen)
        q = self.rng.choice([q for q in unseen if abs(q.level - self.level) == best])
        self.asked.append(q)
        return q

    # Grade an answer and update score, streak and level (the state machine).
    def answer(self, q: Question, choice: int) -> bool:
        ok = choice == q.answer
        if ok:
            # Harder questions are worth more points: 10 x level.
            self.score += 10 * q.level
            self.streak += 1
            # Two correct answers in a row move the learner up one level (max 3).
            if self.streak >= 2 and self.level < 3:
                self.level, self.streak = self.level + 1, 0
        # A wrong answer: record the topic for revision, reset the streak and go down a level (min 1).
        else:
            self.topic_miss[q.topic] += 1
            self.streak = 0
            self.level = max(1, self.level - 1)
        return ok

    # Topics missed most often come first.
    def revision_topics(self) -> list:
        return sorted(self.topic_miss, key=lambda t: -self.topic_miss[t])


# Simulated learner for tests: probability of a correct answer falls as questions get harder.
def simulate(skill: float, seed: int) -> Session:
    """Learner who answers correctly with probability depending on question level."""
    rng = random.Random(seed)
    s = Session(BANK, rng=random.Random(seed))
    # Walrus operator (:=) assigns and tests in one expression; loop ends when next_question() returns None.
    while (q := s.next_question()) is not None:
        p = max(0.05, skill - 0.2 * (q.level - 1))
        # Correct answer with probability p, otherwise deliberately pick a wrong option.
        choice = q.answer if rng.random() < p else (q.answer + 1) % len(q.options)
        s.answer(q, choice)
    return s


# Interactive mode: the same engine, driven by a human through the terminal.
def play() -> None:
    s = Session(BANK)
    while (q := s.next_question()) is not None:
        print(f"\n[Level {q.level}] {q.text}")
        for i, o in enumerate(q.options, 1):
            print(f"  {i}. {o}")
        raw = input("Your answer (1-4): ").strip()
        # Non-numeric input counts as a wrong answer (-1 matches no option).
        ok = s.answer(q, int(raw) - 1 if raw.isdigit() else -1)
        print("Correct!" if ok else f"Not quite - answer: {q.options[q.answer]}")
    print(f"\nScore: {s.score}. Revise: {', '.join(s.revision_topics()) or 'nothing - great job!'}")


# Demo: a nearly-perfect learner (skill 2.0) versus a struggling one (skill 0.15), same seed.
def demo() -> None:
    strong, weak = simulate(2.0, 1), simulate(0.15, 1)
    for name, s in (("strong learner", strong), ("weak learner", weak)):
        print(f"{name}: score={s.score}, final level={s.level}, revise={s.revision_topics()}")
    # 8 questions asked and no question repeated.
    assert len(strong.asked) == 8 == len(set(strong.asked))      # no repeats
    # Always correct -> climbs to the hardest level with nothing to revise.
    assert strong.level == 3 and not strong.revision_topics()   # always right -> hardest level
    assert strong.score > weak.score
    # Mostly wrong -> ends at the easiest level with topics to revise.
    assert weak.level == 1 and weak.revision_topics()           # often wrong -> easy level + revision list
    print("PythonLife adaptive quiz demo OK")


# Run the interactive quiz with --play, otherwise the demo.
if __name__ == "__main__":
    play() if "--play" in sys.argv else demo()
