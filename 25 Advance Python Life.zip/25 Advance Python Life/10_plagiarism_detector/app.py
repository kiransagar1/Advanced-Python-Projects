#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 10 - Code Plagiarism Detector (AST-based)
============================================================
WHAT IT DOES
    Compares Python assignment submissions by their SYNTAX STRUCTURE instead of
    their text. Renaming variables, changing comments/docstrings or reformatting
    does not fool it. Reports every pair of submissions above a similarity limit.

WHAT YOU LEARN
    the ast module (parsing code into trees), recursion over trees, k-gram
    "shingling", Jaccard similarity, why text diffing is not enough.

USAGE
    python app.py                          # demo with assertions
    python app.py folder_of_py_files 0.8   # compare all *.py in a folder
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# ast parses code into a syntax tree - the key to ignoring names and formatting.
import ast
import sys
from itertools import combinations
from pathlib import Path

# Shingle size: we compare every run of 4 consecutive node types.
K = 4  # shingle size: sequences of 4 consecutive node types


# A docstring is the first statement of a module/function/class and a plain string expression. Docstrings are ignored when comparing.
def _is_docstring(parent: ast.AST, child: ast.AST) -> bool:
    return (isinstance(parent, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and parent.body and child is parent.body[0] and isinstance(child, ast.Expr)
            and isinstance(child.value, ast.Constant) and isinstance(child.value.value, str))


# Flatten a syntax tree into a pre-order list of node-type names, e.g. ["FunctionDef", "arguments", ...].
# Variable names, comments and spacing never appear, so renaming cannot hide a copy.
def node_sequence(node: ast.AST, out: list | None = None) -> list:
    """Pre-order list of node type names, ignoring docstrings and Load/Store markers."""
    out = [] if out is None else out
    out.append(type(node).__name__)
    for child in ast.iter_child_nodes(node):
        # Skip Load/Store context markers and docstrings.
        if isinstance(child, ast.expr_context) or _is_docstring(node, child):
            continue
        node_sequence(child, out)
    return out


# Shingling: the set of all K-length windows of the node sequence.
def shingles(source: str) -> set:
    seq = node_sequence(ast.parse(source))
    # Very small programs: use the whole sequence as a single shingle.
    if len(seq) < K:
        return {tuple(seq)}
    return {tuple(seq[i:i + K]) for i in range(len(seq) - K + 1)}


# Jaccard similarity = |A intersect B| / |A union B| (0 = nothing shared, 1 = identical structure).
def similarity(a: str, b: str) -> float:
    sa, sb = shingles(a), shingles(b)
    return len(sa & sb) / len(sa | sb)


# Compare every pair of submissions and return pairs at or above the threshold, most similar first.
def compare_all(submissions: dict, threshold: float = 0.8) -> list:
    sh, out = {}, []
    for name, src in submissions.items():
        # Files that do not parse are skipped instead of crashing the whole run.
        try:
            sh[name] = shingles(src)
        except SyntaxError:
            print(f"skipping {name}: syntax error")
    # combinations() yields each unordered pair once; sorting makes the output deterministic.
    for a, b in combinations(sorted(sh), 2):
        sim = len(sh[a] & sh[b]) / len(sh[a] | sh[b])
        if sim >= threshold:
            out.append((a, b, sim))
    return sorted(out, key=lambda t: -t[2])


# Demo submissions. ORIGINAL is the reference solution (primes by trial division).
ORIGINAL = '''
def primes_upto(n):
    """Return all primes up to n."""
    result = []
    for num in range(2, n + 1):
        is_prime = True
        for d in range(2, int(num ** 0.5) + 1):
            if num % d == 0:
                is_prime = False
                break
        if is_prime:
            result.append(num)
    return result
'''
# RENAMED: identical logic with different variable names and comment - should be detected.
RENAMED = '''
# totally my own work
def get_p(limit):
    found = []
    for x in range(2, limit + 1):
        ok = True
        for y in range(2, int(x ** 0.5) + 1):
            if x % y == 0:
                ok = False
                break
        if ok:
            found.append(x)
    return found
'''
# DIFFERENT: the same task solved with a sieve class - structurally different, should not be flagged.
DIFFERENT = '''
class Sieve:
    def __init__(self, n):
        self.flags = [True] * (n + 1)
        self.n = n
    def run(self):
        i = 2
        while i * i <= self.n:
            if self.flags[i]:
                self.flags[i * i::i] = [False] * len(self.flags[i * i::i])
            i += 1
        return [k for k in range(2, self.n + 1) if self.flags[k]]
'''


# Demo with assertions.
def demo() -> None:
    s_renamed, s_diff = similarity(ORIGINAL, RENAMED), similarity(ORIGINAL, DIFFERENT)
    print(f"original vs renamed copy : {s_renamed:.2f}")
    print(f"original vs sieve class  : {s_diff:.2f}")
    # The renamed copy scores very high; the genuinely different solution scores low.
    assert s_renamed > 0.95 and s_diff < 0.5
    # broken.py has a syntax error and must be skipped, not crash the program.
    pairs = compare_all({"ravi.py": ORIGINAL, "anil.py": RENAMED, "sita.py": DIFFERENT, "broken.py": "def ("}, 0.8)
    print("flagged:", [(a, b, round(s, 2)) for a, b, s in pairs])
    # Only the renamed pair is flagged (names are sorted, so anil.py comes first).
    assert [(a, b) for a, b, _ in pairs] == [("anil.py", "ravi.py")]
    print("PythonLife plagiarism detector demo OK")


# CLI: python app.py <folder> [threshold] compares every .py file in that folder.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        files = {p.name: p.read_text(encoding="utf-8") for p in Path(sys.argv[1]).glob("*.py")}
        thr = float(sys.argv[2]) if len(sys.argv) > 2 else 0.8
        for a, b, s in compare_all(files, thr):
            print(f"{s:.2f}  {a}  <->  {b}")
    else:
        demo()
