#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 21 - Course Roadmap Planner (Dependency Graph)
=================================================================
WHAT IT DOES
    Models courses and their prerequisites as a graph and answers real student questions:
    "In what order should I learn things?", "What do I need before Spring Boot?",
    "Which chain of courses is the longest?", "How many weeks at 8 hours/week?".
    Detects circular prerequisites and shows the exact loop.

WHAT YOU LEARN
    graph algorithms: topological sort (Kahn + heap for stable order), cycle detection
    with DFS, longest path (critical path) by dynamic programming, ancestor closure.

USAGE
    python app.py                          # demo with assertions
    python app.py "Spring Boot" 8          # roadmap to a goal at 8 hours/week
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# heapq is a priority queue (gives alphabetical tie-breaking); sys reads command-line arguments.
import heapq
import sys

# name: (hours, [prerequisites])  - edit freely
COURSES = {
    "Python Basics": (20, []),
    "Python OOP": (15, ["Python Basics"]),
    "Python Advanced": (20, ["Python OOP"]),
    "SQL Basics": (15, []),
    "Oracle SQL": (25, ["SQL Basics"]),
    "PL/SQL": (25, ["Oracle SQL"]),
    "Core Java": (40, []),
    "Spring Boot": (30, ["Core Java", "SQL Basics"]),
    "Data Analysis": (25, ["Python Basics", "SQL Basics"]),
    "Django Web Apps": (30, ["Python OOP", "SQL Basics"]),
    "Docker": (12, []),
    "AWS Basics": (25, ["Docker"]),
}


# Raised when courses depend on each other in a circle (A needs B needs A).
class CycleError(Exception):
    pass


# Convert the catalogue into {course: set of prerequisites}.
def graph_of(courses: dict) -> dict:
    return {n: set(pre) for n, (_, pre) in courses.items()}


# Cycle detection with depth-first search and node colours: WHITE = unseen, GREY = on the current path, BLACK = finished.
def find_cycle(graph: dict):
    """Return a list like ['A','B','A'] if a cycle exists, else None (iterative-safe DFS colours)."""
    WHITE, GREY, BLACK = 0, 1, 2
    # colour tracks every node; stack tracks the current path so the loop can be shown.
    colour, stack = {n: WHITE for n in graph}, []

    def dfs(n):
        colour[n] = GREY
        stack.append(n)
        for p in sorted(graph[n]):
            # Reaching a GREY node means we came back to the current path: a cycle! Return exactly that loop.
            if colour.get(p, BLACK) == GREY:
                return stack[stack.index(p):] + [p]
            # Recurse into unseen prerequisites.
            if colour.get(p) == WHITE and (c := dfs(p)):
                return c
        # All prerequisites explored: mark finished and leave the path.
        colour[n] = BLACK
        stack.pop()
        return None

    # Start a search from every still-unseen node (the graph may be disconnected).
    for n in sorted(graph):
        if colour[n] == WHITE and (c := dfs(n)):
            return c
    return None


# Topological sort (Kahn's algorithm): an order where every course comes after its prerequisites.
def topo_order(graph: dict) -> list:
    """Prerequisites first; ties broken alphabetically so output is stable."""
    # Refuse to continue if a cycle exists, and show the loop in the error message.
    cycle = find_cycle(graph)
    if cycle:
        raise CycleError(" -> ".join(cycle))
    # Prerequisites that are not in the catalogue are a data error.
    missing = {p for pre in graph.values() for p in pre} - set(graph)
    if missing:
        raise KeyError(f"unknown prerequisite(s): {sorted(missing)}")
    # indeg = number of prerequisites still unmet for each course.
    indeg = {n: len(pre) for n, pre in graph.items()}
    # dependants = reverse graph: which courses unlock when this one is done.
    dependants = {n: [] for n in graph}
    for n, pre in graph.items():
        for p in pre:
            dependants[p].append(n)
    # Courses with no prerequisites can start immediately.
    ready = [n for n, d in indeg.items() if d == 0]
    # A heap always pops the alphabetically smallest ready course, so the output order is stable.
    heapq.heapify(ready)
    order = []
    while ready:
        n = heapq.heappop(ready)
        order.append(n)
        # Finishing a course reduces the unmet count of everything that depends on it.
        for m in dependants[n]:
            indeg[m] -= 1
            if indeg[m] == 0:
                heapq.heappush(ready, m)
    return order


# Everything needed for a goal course: walk backwards through prerequisites, then order the sub-graph.
def roadmap_to(goal: str, graph: dict) -> list:
    needed, todo = set(), [goal]
    while todo:
        n = todo.pop()
        if n not in needed:
            needed.add(n)
            todo.extend(graph[n])
    return topo_order({n: graph[n] & needed for n in needed})


# Critical path = the longest chain of prerequisites measured in hours (dynamic programming over the topological order).
def critical_path(graph: dict, hours: dict):
    """Longest chain of prerequisites by total hours -> (path, total_hours)."""
    # finish[n] = earliest total hours to complete n; via[n] = which prerequisite it came through.
    finish, via = {}, {}
    for n in topo_order(graph):
        # The slowest prerequisite decides when this course can begin.
        best = max(graph[n], key=lambda p: finish[p], default=None)
        finish[n] = hours[n] + (finish[best] if best else 0)
        via[n] = best
    # The course finishing last ends the longest chain.
    end = max(finish, key=finish.get)
    # Follow the `via` links backwards to rebuild the path.
    path = []
    while end:
        path.append(end)
        end = via[end]
    # Reverse to get start -> end (after the loop, path[0] is the final course).
    return path[::-1], finish[path[0]]


# Weekly study plan: fill each week with up to per_week hours; a course may spill into the next week.
def weekly_plan(order: list, hours: dict, per_week: int) -> list:
    """Fill weeks sequentially; a course may continue into the next week."""
    weeks, current, room = [], [], per_week
    for course in order:
        left = hours[course]
        while left:
            # Take as many hours as still fit in this week.
            chunk = min(left, room)
            current.append((course, chunk))
            left, room = left - chunk, room - chunk
            # Week is full: save it and start a new one.
            if room == 0:
                weeks.append(current)
                current, room = [], per_week
    if current:
        weeks.append(current)
    return weeks


# Print the roadmap and weekly plan for one goal.
def show(goal: str, per_week: int) -> None:
    g, hours = graph_of(COURSES), {n: h for n, (h, _) in COURSES.items()}
    order = roadmap_to(goal, g)
    print(f"Roadmap to {goal}: {' -> '.join(order)}")
    for i, wk in enumerate(weekly_plan(order, hours, per_week), 1):
        print(f"  Week {i:>2}: " + ", ".join(f"{c} ({h}h)" for c, h in wk))


# Demo with assertions.
def demo() -> None:
    g, hours = graph_of(COURSES), {n: h for n, (h, _) in COURSES.items()}
    order = topo_order(g)
    # Valid order: every prerequisite appears before the course that needs it.
    assert set(order) == set(COURSES) and all(order.index(p) < order.index(n) for n in g for p in g[n])
    rm = roadmap_to("Spring Boot", g)
    # Spring Boot needs Core Java and SQL Basics.
    assert rm == ["Core Java", "SQL Basics", "Spring Boot"], rm
    # Longest chain to PL/SQL is SQL Basics -> Oracle SQL -> PL/SQL = 15+25+25 = 65 hours.
    assert critical_path({n: g[n] for n in roadmap_to("PL/SQL", g)}, hours) == (["SQL Basics", "Oracle SQL", "PL/SQL"], 65)
    path, total = critical_path(g, hours)
    # Longest chain in the whole catalogue: Core Java (40h) -> Spring Boot (30h) = 70 hours.
    assert (path, total) == (["Core Java", "Spring Boot"], 70), (path, total)
    plan = weekly_plan(rm, hours, 8)
    # The plan covers all 85 hours and never exceeds 8 hours a week.
    assert sum(h for wk in plan for _, h in wk) == 40 + 15 + 30 and all(sum(h for _, h in wk) <= 8 for wk in plan)
    assert len(plan) == 11                                     # 85 hours / 8 per week, rounded up
    # Make Core Java depend on Spring Boot (which depends on Core Java) to create a loop.
    bad = graph_of({**COURSES, "Core Java": (40, ["Spring Boot"])})
    try:
        topo_order(bad); raise AssertionError("cycle must be detected")
    except CycleError as e:
        print("cycle found:", e)
        assert "Core Java" in str(e) and "Spring Boot" in str(e)
    show("Spring Boot", 8)
    print("PythonLife roadmap planner demo OK")


# CLI: python app.py <goal course> <hours per week>, or run the demo.
if __name__ == "__main__":
    show(sys.argv[1], int(sys.argv[2])) if len(sys.argv) == 3 else demo()
