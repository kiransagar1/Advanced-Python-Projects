#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 06 - Static Website SEO & Link Auditor
=========================================================
WHAT IT DOES
    Scans a folder of .html files (like the PythonLife website) and scores every
    page on basic SEO health: <title>, meta description, single <h1>, image alt
    text, viewport/lang tags, and BROKEN INTERNAL LINKS (checked on disk).

WHAT YOU LEARN
    html.parser.HTMLParser, pathlib, URL handling (urllib.parse), building a rule
    engine with penalty scoring, writing tests with temporary directories.

USAGE
    python app.py                # demo on a generated mini-site (with assertions)
    python app.py path/to/site   # audit your real folder
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# sys for CLI arguments, tempfile for the demo site, HTMLParser to read pages, pathlib for file paths.
import sys
import tempfile
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlparse

# Link types that are not files on disk and must not be checked as internal links.
SKIP_SCHEMES = ("http", "https", "mailto", "tel", "javascript", "data", "whatsapp")


# Reads one HTML page and records the SEO facts we care about.
class PageInfo(HTMLParser):
    """Collects the facts we need from one HTML document."""

    def __init__(self):
        # convert_charrefs turns &amp; style entities into normal characters.
        super().__init__(convert_charrefs=True)
        # Fields filled while parsing: title, meta description, <html lang>, number of <h1>, viewport meta, images without alt, links.
        self.title, self.description, self.lang = "", "", ""
        self.h1, self.viewport = 0, False
        self.imgs_no_alt, self.links = 0, []
        self._in_title = False

    # Called by HTMLParser for every opening tag.
    def handle_starttag(self, tag, attrs):
        # Turn the attribute list into a dictionary (missing values become empty strings).
        a = {k: (v or "") for k, v in attrs}
        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._in_title = True
        elif tag == "h1":
            self.h1 += 1
        elif tag == "meta":
            if a.get("name", "").lower() == "description":
                self.description = a.get("content", "").strip()
            elif a.get("name", "").lower() == "viewport":
                self.viewport = True
        # An <img> with empty or missing alt text hurts accessibility and SEO.
        elif tag == "img" and not a.get("alt", "").strip():
            self.imgs_no_alt += 1
        # Collect every link target for the broken-link check.
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"])

    # Stop collecting title text at </title>.
    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    # Text found while inside <title> becomes the page title.
    def handle_data(self, data):
        if self._in_title:
            self.title += data


# Work out which file on disk an internal link points to.
def resolve(root: Path, page: Path, href: str):
    """Return the file an internal href points to, or None if it is external/ignorable."""
    u = urlparse(href.strip())
    # External links (http, mailto, ...) and pure #anchors are ignored.
    if u.scheme in SKIP_SCHEMES or u.netloc or not u.path:
        return None
    # Links beginning with / are relative to the site root, others to the current page's folder.
    base = root if u.path.startswith("/") else page.parent
    target = (base / unquote(u.path).lstrip("/")).resolve()
    # A link to a folder means that folder's index.html.
    return target / "index.html" if target.is_dir() else target


# Audit one page and give it a score out of 100.
def audit_page(root: Path, page: Path) -> dict:
    info = PageInfo()
    info.feed(page.read_text(encoding="utf-8", errors="replace"))
    # Each issue is recorded as (code, penalty points).
    issues = []  # (code, penalty)

    def add(code, penalty):
        issues.append((code, penalty))

    # Scoring rules: each failed check removes points from 100.
    t = info.title.strip()
    if not t: add("missing-title", 20)
    elif not 10 <= len(t) <= 60: add("title-length(10-60)", 5)
    if not info.description: add("missing-meta-description", 15)
    elif len(info.description) > 160: add("meta-description>160", 5)
    if info.h1 == 0: add("missing-h1", 10)
    elif info.h1 > 1: add("multiple-h1", 5)
    if not info.lang: add("missing-html-lang", 5)
    if not info.viewport: add("missing-viewport", 5)
    # Count at most 5 missing-alt images so one bad page cannot dominate.
    for _ in range(min(info.imgs_no_alt, 5)): add("image-without-alt", 3)
    for href in info.links:
        target = resolve(root, page, href)
        # Internal link whose target file does not exist -> broken link.
        if target is not None and not target.exists():
            add(f"broken-link:{href}", 5)
    # Final score is 100 minus all penalties, never below 0.
    score = max(0, 100 - sum(p for _, p in issues))
    return {"page": page.relative_to(root).as_posix(), "score": score, "issues": [c for c, _ in issues]}


# Audit every .html file under the site folder (recursive).
def audit_site(root) -> list:
    root = Path(root).resolve()
    return [audit_page(root, p) for p in sorted(root.rglob("*.html"))]


# Print each page's score and issues, then the site average.
def print_report(results: list) -> None:
    for r in results:
        print(f"{r['score']:>3}  {r['page']}")
        for i in r["issues"]:
            print(f"       - {i}")
    if results:
        print(f"Average score: {sum(r['score'] for r in results) / len(results):.1f}")


# Demo pages: GOOD follows every rule; BAD breaks nearly all of them.
GOOD = """<!doctype html><html lang="en"><head><title>PythonLife - Learn Python in Telugu</title>
<meta name="description" content="Live and recorded Python, SQL and Java courses taught in Telugu."><meta name="viewport" content="width=device-width">
</head><body><h1>Welcome</h1><a href="about.html">About</a> <a href="/courses/">Courses</a>
<a href="https://example.com">ext</a><img src="a.png" alt="logo"></body></html>"""
BAD = """<html><head></head><body><h1>A</h1><h1>B</h1><img src="x.png"><a href="missing.html#top">x</a></body></html>"""


# Build a small site in a temporary folder and audit it.
def demo() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "courses").mkdir()
        (root / "index.html").write_text(GOOD, encoding="utf-8")
        (root / "about.html").write_text(GOOD.replace('href="about.html"', 'href="index.html"'), encoding="utf-8")
        (root / "courses" / "index.html").write_text(GOOD.replace('href="about.html"', 'href="../index.html"'), encoding="utf-8")
        (root / "bad.html").write_text(BAD, encoding="utf-8")
        results = {r["page"]: r for r in audit_site(root)}
        print_report(list(results.values()))
        # The well-formed pages must score a perfect 100.
        assert results["index.html"]["score"] == 100, results["index.html"]
        assert results["courses/index.html"]["score"] == 100
        # The bad page must trigger every expected issue code.
        bad = results["bad.html"]["issues"]
        for code in ("missing-title", "missing-meta-description", "multiple-h1", "missing-html-lang",
                     "missing-viewport", "image-without-alt", "broken-link:missing.html#top"):
            assert code in bad, code
        assert results["bad.html"]["score"] < 50
    print("PythonLife SEO auditor demo OK")


# Pass a folder to audit a real site; with no arguments run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        print_report(audit_site(sys.argv[1]))
    else:
        demo()
