#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 13 - Web Server Log Analyzer & Scanner Detector
==================================================================
WHAT IT DOES
    Parses Nginx/Apache "combined" access logs and reports traffic, status-code
    classes, top pages, bandwidth, busiest minute and the 95th-percentile response
    size. It also flags suspicious IPs that probe for secrets (/.env, /wp-login.php,
    /phpmyadmin ...) or produce many 4xx errors - handy for your own website.

WHAT YOU LEARN
    named-group regular expressions, streaming files line by line, Counter and
    defaultdict, datetime parsing with timezones, simple anomaly rules.

USAGE
    python app.py                # demo on synthetic logs (with assertions)
    python app.py access.log     # analyze a real log file
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# random makes sample traffic, re parses lines, Counter tallies, datetime handles time zones.
import random
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

# Regex for the Nginx/Apache "combined" log format. Named groups: client IP, timestamp,
# request method and path, status code, response size, referrer and user agent.
LINE = re.compile(r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<method>[A-Z]+) (?P<path>\S+) [^"]*" '
                  r'(?P<status>\d{3}) (?P<size>\d+|-) "(?P<ref>[^"]*)" "(?P<ua>[^"]*)"')
# Paths that scanners probe (secret files, admin panels, WordPress/PHPMyAdmin endpoints).
PROBES = re.compile(r"(\.env|wp-login|phpmyadmin|\.git/|xmlrpc|/admin|\.php$|etc/passwd)", re.I)
# Timestamp format used in access logs, e.g. 13/Nov/2026:10:00:00 +0530.
TS_FORMAT = "%d/%b/%Y:%H:%M:%S %z"


# Parse log lines lazily (generator). Lines that do not match are counted as malformed.
def parse(lines):
    """Yield dicts for valid lines; count the malformed ones in parse.bad."""
    # Function attribute used as a simple counter that callers can read after iterating.
    parse.bad = 0
    for raw in lines:
        m = LINE.match(raw.strip())
        if not m:
            parse.bad += 1
            continue
        d = m.groupdict()
        # Convert status/size to integers; a size of "-" means no body (0 bytes).
        d["status"], d["size"] = int(d["status"]), 0 if d["size"] == "-" else int(d["size"])
        # Parse the timestamp into a timezone-aware datetime.
        d["time"] = datetime.strptime(d["ts"], TS_FORMAT)
        # Drop the ?query-string so /page?a=1 and /page?a=2 count as one page.
        d["path"] = d["path"].split("?")[0]
        yield d


# Analyse all log lines and return the statistics as a dictionary.
def analyze(lines, scan_min_4xx: int = 10) -> dict:
    total = bytes_sent = 0
    # Counters: status classes (2xx/4xx), pages, requests per minute.
    classes, paths, per_minute = Counter(), Counter(), Counter()
    # sizes feeds the percentile; ip_4xx and ip_probes track suspicious clients.
    sizes, ip_4xx, ip_probes = [], Counter(), Counter()
    for r in parse(lines):
        total += 1
        bytes_sent += r["size"]
        sizes.append(r["size"])
        # Group status codes into 2xx / 3xx / 4xx / 5xx.
        classes[f"{r['status'] // 100}xx"] += 1
        paths[r["path"]] += 1
        per_minute[r["time"].strftime("%H:%M")] += 1
        # Count client errors (4xx) per IP address.
        if 400 <= r["status"] < 500:
            ip_4xx[r["ip"]] += 1
        # Count requests for probe-like paths per IP address.
        if PROBES.search(r["path"]):
            ip_probes[r["ip"]] += 1
    # Sort sizes so the 95th percentile can be read by index.
    sizes.sort()
    # Suspects = IPs with many 4xx errors (default 10+) OR 3+ probe requests.
    suspects = sorted({ip for ip, n in ip_4xx.items() if n >= scan_min_4xx} | {ip for ip, n in ip_probes.items() if n >= 3})
    return {"requests": total, "malformed": parse.bad, "bytes": bytes_sent, "classes": dict(classes),
            "top_paths": paths.most_common(5), "busiest_minute": per_minute.most_common(1)[0] if per_minute else None,
            # p95 size: the value that 95% of responses do not exceed.
            "p95_size": sizes[int(0.95 * (len(sizes) - 1))] if sizes else 0, "suspects": suspects}


# Build a repeatable fake log: 300 normal visitors plus one scanner IP plus a corrupt line.
def synthetic_log(seed: int = 5) -> list:
    rng = random.Random(seed)
    # Start time with the Indian time zone offset (+05:30).
    t0 = datetime(2026, 11, 13, 10, 0, 0, tzinfo=timezone(timedelta(hours=5, minutes=30)))
    pages = ["/", "/about-us", "/reviews", "/free-courses-in-telugu", "/oracle-sql"]
    lines = []
    for i in range(300):
        # Random visitor IP address.
        ip = f"49.37.{rng.randint(1, 20)}.{rng.randint(1, 250)}"
        ts = (t0 + timedelta(seconds=i * 2)).strftime(TS_FORMAT)
        lines.append(f'{ip} - - [{ts}] "GET {rng.choice(pages)} HTTP/1.1" 200 {rng.randint(2000, 60000)} "-" "Mozilla/5.0"')
    # The scanner requests four sensitive paths six times each (24 requests, all 404).
    for i, p in enumerate(["/.env", "/wp-login.php", "/phpmyadmin/", "/.git/config"] * 6):
        ts = (t0 + timedelta(seconds=100 + i)).strftime(TS_FORMAT)
        lines.append(f'185.220.1.9 - - [{ts}] "GET {p} HTTP/1.1" 404 153 "-" "curl/8.0"')
    # A corrupt line to prove the parser tolerates bad input.
    lines.append("this line is not a valid log entry")
    return lines


# Print the analysis in a readable form.
def print_report(r: dict) -> None:
    print(f"Requests: {r['requests']}  Malformed: {r['malformed']}  Bandwidth: {r['bytes'] / 1e6:.2f} MB")
    print("Status classes:", r["classes"], "| p95 size:", r["p95_size"], "bytes")
    print("Top paths:", r["top_paths"])
    print("Busiest minute:", r["busiest_minute"])
    print("Suspicious IPs:", r["suspects"])


# Demo with assertions.
def demo() -> None:
    r = analyze(synthetic_log())
    print_report(r)
    # 300 + 24 + 0 valid requests = 324, plus 1 malformed line.
    assert r["requests"] == 324 and r["malformed"] == 1
    assert r["classes"] == {"2xx": 300, "4xx": 24}
    # Only the scanner IP is flagged.
    assert r["suspects"] == ["185.220.1.9"]
    assert r["top_paths"][0][1] >= 40 and r["p95_size"] > 50000
    print("PythonLife log analyzer demo OK")


# CLI: pass a log file path, or run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8", errors="replace") as f:
            print_report(analyze(f))
    else:
        demo()
