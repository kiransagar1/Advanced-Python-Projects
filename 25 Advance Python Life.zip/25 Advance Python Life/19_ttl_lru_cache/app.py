#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 19 - Thread-Safe TTL + LRU Cache Decorator
=============================================================
WHAT IT DOES
    @cached(maxsize=100, ttl=60) memoizes a function. Entries expire after `ttl`
    seconds, the least-recently-used entry is evicted when full, statistics are
    tracked, and - the advanced part - concurrent callers asking for the SAME missing
    key share ONE computation instead of stampeding your database/API ("thundering herd").

WHAT YOU LEARN
    decorators with arguments, functools.wraps, OrderedDict as an LRU structure,
    locks and threading.Event, injectable clocks for deterministic tests.

USAGE
    python app.py        # demo with assertions
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# threading provides locks/events, OrderedDict keeps recency order, wraps preserves the decorated function's name.
import threading
import time
from collections import OrderedDict, namedtuple
from functools import wraps

# Statistics object returned by cache_info().
CacheInfo = namedtuple("CacheInfo", "hits misses expirations evictions size")


# @cached(maxsize, ttl): memoise a function with LRU eviction, optional expiry, and stampede protection.
# `clock` is injectable so tests can fake the passage of time.
def cached(maxsize: int = 128, ttl: float | None = None, clock=time.monotonic):
    def decorator(fn):
        # OrderedDict doubles as the LRU list: the oldest entry sits at the front, the newest at the end.
        store: OrderedDict = OrderedDict()      # key -> (value, stored_at); order = recency
        # Keys currently being computed, each with an Event others can wait on.
        inflight: dict = {}                     # key -> Event for computations in progress
        # RLock = re-entrant lock protecting all shared state (the wrapper can call itself).
        lock = threading.RLock()
        c = {"hits": 0, "misses": 0, "expirations": 0, "evictions": 0}

        @wraps(fn)
        # The replacement function that checks the cache before calling the real one.
        def wrapper(*args, **kwargs):
            # Cache key built from positional and keyword arguments (arguments must be hashable).
            key = (args, tuple(sorted(kwargs.items())))
            with lock:
                entry = store.get(key)
                if entry is not None:
                    # Entry is fresh if no TTL is set or it is younger than ttl seconds.
                    if ttl is None or clock() - entry[1] < ttl:
                        # Cache hit: mark the key as most recently used and return the stored value.
                        store.move_to_end(key)
                        c["hits"] += 1
                        return entry[0]
                    # Stale entry: remove it and fall through to recompute.
                    del store[key]
                    c["expirations"] += 1
                # Is another thread already computing this key? The first caller becomes the "leader".
                event = inflight.get(key)
                leader = event is None
                if leader:
                    event = inflight[key] = threading.Event()
            # Followers wait for the leader's result, then call again (and now get a cache hit).
            if not leader:                       # someone else is computing this key: wait, then re-check
                event.wait()
                return wrapper(*args, **kwargs)
            # The leader calls the real function OUTSIDE the lock, so slow work never blocks other keys.
            try:
                value = fn(*args, **kwargs)
            # On failure: clean up and wake the waiters, so errors are not cached and nobody waits forever.
            except BaseException:
                with lock:
                    inflight.pop(key, None)
                event.set()
                raise
            # Store the new value with its timestamp and count a miss.
            with lock:
                store[key] = (value, clock())
                c["misses"] += 1
                # LRU eviction: drop the least-recently-used entries while over maxsize.
                while len(store) > maxsize:
                    store.popitem(last=False)
                    c["evictions"] += 1
                inflight.pop(key, None)
            # Wake every follower waiting for this key.
            event.set()
            return value

        # Introspection helper: current hit/miss/expiry/eviction counters and size.
        def cache_info() -> CacheInfo:
            with lock:
                return CacheInfo(c["hits"], c["misses"], c["expirations"], c["evictions"], len(store))

        # Empty the cache and reset the counters.
        def cache_clear() -> None:
            with lock:
                store.clear()
                for k in c:
                    c[k] = 0

        # Expose the helpers on the decorated function, like functools.lru_cache does.
        wrapper.cache_info, wrapper.cache_clear = cache_info, cache_clear
        return wrapper
    return decorator


# A controllable clock so the demo can "advance time" instantly instead of sleeping.
class FakeClock:
    def __init__(self): self.t = 0.0
    def __call__(self): return self.t
    def advance(self, s): self.t += s


# Demo with assertions.
def demo() -> None:
    clock, calls = FakeClock(), []

    # Cache of size 2 whose entries expire after 10 (fake) seconds.
    @cached(maxsize=2, ttl=10, clock=clock)
    def square(n):
        calls.append(n)
        return n * n

    # Second call is served from the cache, so the function ran only once.
    assert square(3) == 9 and square(3) == 9 and calls == [3]            # second call is a hit
    # Calling square(3) again makes 3 the most recently used entry.
    square(4); square(3)                                                  # 3 is now most recent
    # Cache is full: adding 5 evicts the least recently used key (4).
    square(5)                                                             # evicts 4 (least recently used)
    assert square.cache_info().evictions == 1 and 4 not in calls[3:] and square.cache_info().size == 2
    # 4 was evicted, so it has to be recomputed.
    square(4); assert calls == [3, 4, 5, 4]                               # 4 had to be recomputed
    # Move the fake clock past the 10-second TTL.
    clock.advance(11)
    square(5); assert calls[-1] == 5                                      # expired -> recomputed
    assert square.cache_info().expirations >= 1
    square.cache_clear(); assert square.cache_info() == CacheInfo(0, 0, 0, 0, 0)

    # Stampede test: 8 threads ask for the same missing key at once.
    herd_calls = []

    @cached(maxsize=10)
    def slow_lookup(key):
        herd_calls.append(key)
        time.sleep(0.1)
        return key.upper()

    results = []
    # Eight threads call the slow function simultaneously.
    threads = [threading.Thread(target=lambda: results.append(slow_lookup("python"))) for _ in range(8)]
    for t in threads: t.start()
    for t in threads: t.join()
    print("8 concurrent callers -> function executed", len(herd_calls), "time(s); info:", slow_lookup.cache_info())
    # Only ONE computation happened, and all eight callers got the same result.
    assert results == ["PYTHON"] * 8 and herd_calls == ["python"]         # one computation shared by all

    # A function that always fails: exceptions must not be cached.
    @cached()
    def boom(x):
        raise ValueError("nope")
    for _ in range(2):
        try:
            boom(1); raise AssertionError
        except ValueError:
            pass                                                           # errors are not cached
    print("PythonLife TTL/LRU cache demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo()
