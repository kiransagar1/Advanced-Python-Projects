#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 02 - Verifiable Certificate Generator
========================================================
WHAT IT DOES
    Creates print-ready SVG course certificates (black/orange PythonLife theme)
    and gives each a tamper-proof certificate ID built with HMAC-SHA256. Anyone
    with the secret can later verify that an ID really belongs to a name,
    course and date - so fake certificates are easy to catch.

WHAT YOU LEARN
    hmac / hashlib, constant-time comparison, safe text escaping (html.escape),
    generating vector graphics as text, XML validation with ElementTree.

USAGE
    python app.py                                   # demo with assertions
    python app.py issue --name "Ravi Kumar" --course "Python Full Course" --out cert.svg
    python app.py verify --id PL-XXXX --name "Ravi Kumar" --course "Python Full Course" --date 2026-11-13
Set PYTHONLIFE_CERT_SECRET in your environment for real use.
"""
# Postponed evaluation of annotations (keeps type hints lightweight).
from __future__ import annotations

# Standard-library modules: hmac/hashlib for signatures, html for escaping,
# ElementTree to validate the generated SVG, tempfile for a safe demo folder.
import argparse
import hashlib
import hmac
import html
import os
import tempfile
import xml.etree.ElementTree as ET
from datetime import date

# Secret key for signing certificate IDs. Read from the environment so it never lives in
# source control; the fallback value is only a placeholder for demos.
SECRET = os.environ.get("PYTHONLIFE_CERT_SECRET", "change-me-in-production").encode()


# Builds the tamper-proof ID: HMAC-SHA256 over the normalised name|course|date.
def cert_id(name: str, course: str, issued: date) -> str:
    """Deterministic ID: same inputs -> same ID; any change -> a different ID."""
    # Normalise (strip + lowercase) so "  Ravi " and "ravi" produce the same ID.
    msg = f"{name.strip().lower()}|{course.strip().lower()}|{issued.isoformat()}".encode()
    # Keep the first 12 hex characters in upper case: short enough to print, long enough to be unguessable.
    return "PL-" + hmac.new(SECRET, msg, hashlib.sha256).hexdigest()[:12].upper()


# Recompute the expected ID and compare it with the one supplied.
def verify(cid: str, name: str, course: str, issued: date) -> bool:
    # compare_digest takes constant time, which prevents timing attacks on the comparison.
    return hmac.compare_digest(cid.strip().upper(), cert_id(name, course, issued))


# Generate the certificate as SVG (vector graphics written as plain text).
def render_svg(name: str, course: str, issued: date, instructor: str = "Kiran Sagar") -> str:
    cid = cert_id(name, course, issued)
    # Shrink the font for long names so they still fit inside the border (minimum 28 px).
    size = 54 if len(name) <= 20 else max(28, int(54 - (len(name) - 20) * 1.5))
    # html.escape converts < > & into entities, so a hostile name cannot inject markup.
    e = html.escape  # never trust user text inside markup
    # The SVG template (an f-string): two orange borders, title, recipient, course, date,
    # instructor and the verifiable certificate ID.
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1123" height="794" viewBox="0 0 1123 794">
  <rect width="1123" height="794" fill="#111"/>
  <rect x="24" y="24" width="1075" height="746" fill="none" stroke="#ff7a00" stroke-width="6"/>
  <rect x="44" y="44" width="1035" height="706" fill="none" stroke="#ff7a00" stroke-width="1.5"/>
  <text x="561" y="130" text-anchor="middle" font-family="Georgia,serif" font-size="30" fill="#ff7a00" letter-spacing="6">PYTHONLIFE</text>
  <text x="561" y="215" text-anchor="middle" font-family="Georgia,serif" font-size="50" fill="#fff">Certificate of Completion</text>
  <text x="561" y="300" text-anchor="middle" font-family="Arial,sans-serif" font-size="22" fill="#bbb">This is to certify that</text>
  <text x="561" y="385" text-anchor="middle" font-family="Georgia,serif" font-size="{size}" font-style="italic" fill="#ff7a00">{e(name)}</text>
  <text x="561" y="450" text-anchor="middle" font-family="Arial,sans-serif" font-size="22" fill="#bbb">has successfully completed the course</text>
  <text x="561" y="515" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="bold" fill="#fff">{e(course)}</text>
  <text x="180" y="660" font-family="Arial,sans-serif" font-size="18" fill="#bbb">Date: {issued.isoformat()}</text>
  <text x="943" y="660" text-anchor="end" font-family="Arial,sans-serif" font-size="18" fill="#bbb">Instructor: {e(instructor)}</text>
  <text x="561" y="720" text-anchor="middle" font-family="monospace" font-size="16" fill="#ff7a00">Certificate ID: {cid}</text>
</svg>"""


# Demo with assertions: proves signing, verification and escaping all work.
def demo() -> None:
    d = date(2026, 11, 13)
    cid = cert_id("Ravi Kumar", "Python Full Course", d)
    # IDs look like PL-XXXXXXXXXXXX (3 + 12 = 15 characters).
    assert cid.startswith("PL-") and len(cid) == 15
    # Verification ignores case and extra spaces.
    assert verify(cid, "  ravi kumar ", "python full course", d)          # case/space tolerant
    # Changing the date must invalidate the certificate.
    assert not verify(cid, "Ravi Kumar", "Python Full Course", date(2026, 11, 14))  # date tampered
    # Changing the name must invalidate the certificate.
    assert not verify(cid, "Someone Else", "Python Full Course", d)                  # name tampered
    # Hostile characters in the name/course must be neutralised, not rendered.
    svg = render_svg("Ravi <b>&</b> Kumar", "Python & SQL", d)
    # ElementTree raises ParseError if the SVG is not well-formed XML.
    ET.fromstring(svg)                                    # raises if XML is not well formed
    assert "<b>" not in svg and "&lt;b&gt;" in svg        # injection neutralised
    # Write a real file inside a temporary directory that is deleted afterwards.
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "cert.svg")
        with open(path, "w", encoding="utf-8") as f:
            f.write(render_svg("Ravi Kumar", "Python Full Course", d))
        assert os.path.getsize(path) > 1000
    print("PythonLife certificate demo OK ->", cid)


# CLI with two sub-commands: issue (create a certificate) and verify (check an ID).
def main() -> None:
    p = argparse.ArgumentParser(description="PythonLife certificate generator")
    sub = p.add_subparsers(dest="cmd")
    i = sub.add_parser("issue"); i.add_argument("--name", required=True); i.add_argument("--course", required=True)
    i.add_argument("--date", default=date.today().isoformat()); i.add_argument("--out", default="certificate.svg")
    v = sub.add_parser("verify"); v.add_argument("--id", required=True); v.add_argument("--name", required=True)
    v.add_argument("--course", required=True); v.add_argument("--date", required=True)
    a = p.parse_args()
    # issue: create the SVG file and print its ID.
    if a.cmd == "issue":
        d = date.fromisoformat(a.date)
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(render_svg(a.name, a.course, d))
        print("written", a.out, cert_id(a.name, a.course, d))
    # verify: print VALID or INVALID.
    elif a.cmd == "verify":
        ok = verify(a.id, a.name, a.course, date.fromisoformat(a.date))
        print("VALID" if ok else "INVALID")
    # No sub-command given: run the demo.
    else:
        demo()


# Entry point guard.
if __name__ == "__main__":
    main()
