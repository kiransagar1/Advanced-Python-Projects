#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 01 - Student Progress Tracker
================================================
WHAT IT DOES
    Tracks students, course enrollments, daily attendance and lesson progress
    in a SQLite database, then prints a report that flags students who are
    AT RISK (attendance below 75%) so the trainer can follow up early.

WHAT YOU LEARN
    sqlite3, foreign keys + CHECK constraints, JOIN/GROUP BY/aggregates,
    argparse sub-commands, writing a small class-based data layer.

USAGE
    python app.py                                  # self-checking demo (in-memory DB)
    python app.py --db pl.db add-student "Ravi" --phone 9876543210
    python app.py --db pl.db enroll 1 "Python Full Course" 40
    python app.py --db pl.db attend 1 2026-11-13 --absent
    python app.py --db pl.db done 1 --lessons 3
    python app.py --db pl.db report
"""
# Postponed evaluation of type hints so modern syntax (list[dict]) works cleanly.
from __future__ import annotations

# Standard-library imports only - this project needs no pip install.
import argparse
import sqlite3

# Brand line printed by the demo.
BRAND = "PythonLife | Learn. Build. Grow."
# Students whose attendance falls below this percentage are flagged AT RISK.
RISK_ATTENDANCE = 75.0  # percent

# Database schema. IF NOT EXISTS makes it safe to run on every start-up.
# students: one row per person.
# enrollments: a student joined to a course; the CHECK stops a course with 0 lessons;
#   UNIQUE(student_id, course) blocks duplicate enrollments; ON DELETE CASCADE removes
#   dependent rows automatically.
# attendance: one row per enrollment per day; present is stored as 0/1.
SCHEMA = """
CREATE TABLE IF NOT EXISTS students(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS enrollments(
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course TEXT NOT NULL,
    total_lessons INTEGER NOT NULL CHECK(total_lessons > 0),
    lessons_done INTEGER NOT NULL DEFAULT 0,
    UNIQUE(student_id, course));
CREATE TABLE IF NOT EXISTS attendance(
    enrollment_id INTEGER NOT NULL REFERENCES enrollments(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    present INTEGER NOT NULL CHECK(present IN (0, 1)),
    PRIMARY KEY(enrollment_id, day));
"""


# Tracker is the data-access layer: all SQL lives here, the UI code below just calls methods.
class Tracker:
    """Small data-access layer around the SQLite database."""

    def __init__(self, path: str = ":memory:"):
        # ":memory:" gives a throw-away database - perfect for tests and demos.
        self.db = sqlite3.connect(path)
        # Row factory lets us read columns by name (row["name"]) instead of by index.
        self.db.row_factory = sqlite3.Row
        # SQLite ignores foreign keys unless this pragma is switched on for every connection.
        self.db.execute("PRAGMA foreign_keys = ON")
        # Create the tables if they do not exist yet.
        self.db.executescript(SCHEMA)

    def add_student(self, name: str, phone: str = "") -> int:
        # Reject empty / whitespace-only names before touching the database.
        if not name.strip():
            raise ValueError("student name is required")
        # Placeholders (?) keep user input out of the SQL text, which prevents SQL injection.
        cur = self.db.execute("INSERT INTO students(name, phone) VALUES (?, ?)", (name.strip(), phone))
        self.db.commit()
        # lastrowid is the auto-generated id of the row we just inserted.
        return cur.lastrowid

    def enroll(self, student_id: int, course: str, total_lessons: int) -> int:
        cur = self.db.execute(
            "INSERT INTO enrollments(student_id, course, total_lessons) VALUES (?, ?, ?)",
            (student_id, course, total_lessons))
        self.db.commit()
        return cur.lastrowid

    def mark_attendance(self, enrollment_id: int, day: str, present: bool) -> None:
        """Insert or overwrite the attendance record for that day."""
        # INSERT OR REPLACE overwrites an existing (enrollment, day) row - re-marking a day is allowed.
        self.db.execute("INSERT OR REPLACE INTO attendance VALUES (?, ?, ?)",
                        (enrollment_id, day, int(present)))
        self.db.commit()

    def complete_lessons(self, enrollment_id: int, n: int = 1) -> None:
        """Add n finished lessons, never exceeding the course total."""
        # SQL MIN() caps lessons_done so it can never exceed total_lessons.
        self.db.execute("UPDATE enrollments SET lessons_done = MIN(total_lessons, lessons_done + ?) WHERE id = ?",
                        (n, enrollment_id))
        self.db.commit()

    def report(self) -> list[dict]:
        # One query builds the whole report: JOIN students, LEFT JOIN attendance so students
        # with no attendance rows still appear (days = 0), GROUP BY enrollment for aggregates.
        rows = self.db.execute("""
            SELECT s.name, e.id AS eid, e.course, e.lessons_done, e.total_lessons,
                   COUNT(a.present) AS days, COALESCE(SUM(a.present), 0) AS present_days
            FROM enrollments e
            JOIN students s ON s.id = e.student_id
            LEFT JOIN attendance a ON a.enrollment_id = e.id
            GROUP BY e.id ORDER BY s.name, e.course""").fetchall()
        # Convert raw counts into percentages and a human-readable status.
        out = []
        for r in rows:
            # attendance % is None (not 0) when there are no records, so "no data" differs from "always absent".
            att = 100.0 * r["present_days"] / r["days"] if r["days"] else None
            prog = 100.0 * r["lessons_done"] / r["total_lessons"]
            # Status rules: NO DATA -> AT RISK (below threshold) -> OK.
            status = "NO DATA" if att is None else ("AT RISK" if att < RISK_ATTENDANCE else "OK")
            out.append({"student": r["name"], "enrollment": r["eid"], "course": r["course"],
                        "attendance": att, "progress": prog, "status": status})
        return out


# Pretty-print the report as an aligned text table (the :<12 / :>8 are width + alignment).
def print_report(rows: list[dict]) -> None:
    print(f"{'Student':<12}{'Course':<22}{'Attend%':>8}{'Progress%':>10}  Status")
    for r in rows:
        att = "-" if r["attendance"] is None else f"{r['attendance']:.0f}"
        print(f"{r['student']:<12}{r['course']:<22}{att:>8}{r['progress']:>10.0f}  {r['status']}")


# Self-checking demo: builds sample data in memory and asserts the results.
def demo() -> None:
    print(BRAND, "- Student Tracker demo")
    t = Tracker()
    # Generator expression unpacked into three variables: the new student ids.
    ravi, sita, anil = (t.add_student(n) for n in ("Ravi", "Sita", "Anil"))
    e1, e2, e3 = (t.enroll(s, "Python Full Course", 40) for s in (ravi, sita, anil))
    # Eight consecutive days: 2026-11-01 .. 2026-11-08.
    for i, day in enumerate(f"2026-11-{d:02d}" for d in range(1, 9)):
        t.mark_attendance(e1, day, True)              # Ravi: always present
        t.mark_attendance(e2, day, i % 2 == 0)        # Sita: 50%
    # Asking for 100 lessons on a 40-lesson course must be capped at 40.
    t.complete_lessons(e1, 100)                        # capped at 40
    t.complete_lessons(e2, 10)
    rep = {r["student"]: r for r in t.report()}
    print_report(list(rep.values()))
    # Ravi was always present and finished everything -> OK and 100% progress.
    assert rep["Ravi"]["status"] == "OK" and rep["Ravi"]["progress"] == 100.0
    # Sita attended every other day -> 50%, below the 75% limit -> AT RISK.
    assert rep["Sita"]["status"] == "AT RISK" and round(rep["Sita"]["attendance"]) == 50
    # Anil has no attendance rows at all -> NO DATA.
    assert rep["Anil"]["status"] == "NO DATA"
    # A duplicate enrollment must be rejected by the UNIQUE constraint.
    try:
        t.enroll(ravi, "Python Full Course", 40)
        raise AssertionError("duplicate enrollment must fail")
    except sqlite3.IntegrityError:
        pass
    print("PythonLife student tracker demo OK")


# Command-line interface built with argparse sub-commands (add-student, enroll, ...).
def main() -> None:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    p.add_argument("--db", default=None, help="SQLite file (omit to run the demo)")
    sub = p.add_subparsers(dest="cmd")
    a = sub.add_parser("add-student"); a.add_argument("name"); a.add_argument("--phone", default="")
    a = sub.add_parser("enroll"); a.add_argument("student_id", type=int); a.add_argument("course"); a.add_argument("total", type=int)
    a = sub.add_parser("attend"); a.add_argument("enrollment_id", type=int); a.add_argument("day"); a.add_argument("--absent", action="store_true")
    a = sub.add_parser("done"); a.add_argument("enrollment_id", type=int); a.add_argument("--lessons", type=int, default=1)
    sub.add_parser("report")
    args = p.parse_args()
    # Without --db or a sub-command we run the demo instead.
    if not args.db or not args.cmd:
        return demo()
    # Open (or create) the SQLite file and dispatch to the requested action.
    t = Tracker(args.db)
    if args.cmd == "add-student":
        print("student id:", t.add_student(args.name, args.phone))
    elif args.cmd == "enroll":
        print("enrollment id:", t.enroll(args.student_id, args.course, args.total))
    elif args.cmd == "attend":
        t.mark_attendance(args.enrollment_id, args.day, not args.absent); print("saved")
    elif args.cmd == "done":
        t.complete_lessons(args.enrollment_id, args.lessons); print("saved")
    else:
        print_report(t.report())


# Run main() only when executed directly, not when imported as a module.
if __name__ == "__main__":
    main()
