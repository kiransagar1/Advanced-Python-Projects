#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 08 - GST Invoice & Fee Receipt Generator
===========================================================
WHAT IT DOES
    Builds GST-compliant invoices for course fees: automatic CGST+SGST (same
    state) or IGST (other state), Indian financial-year invoice numbers like
    PL/2026-27/0001, exact Decimal arithmetic, "amount in words" using the
    lakh/crore system, and a clean printable HTML invoice.

WHAT YOU LEARN
    decimal.Decimal for money (never float!), rounding rules, Indian number
    system, HTML templating with escaping, dataclasses.

USAGE
    python app.py            # demo with assertions; writes sample_invoice.html to a temp dir
    python app.py --write    # writes sample_invoice.html in the current folder
Note: tax rules change - confirm rates and invoice format with your accountant.
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# Decimal gives exact money arithmetic (floats cannot represent 0.1 exactly); html.escape protects the invoice page.
import html
import sys
import tempfile
from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

# Seller details. The state decides CGST+SGST (same state) versus IGST (other state). Replace the GSTIN with real data.
SELLER = {"name": "PythonLife", "state": "Telangana", "gstin": "XXXXXXXXXXXXXXX"}  # replace with real details
# Smallest money unit: 0.01 rupee (1 paisa).
CENT = Decimal("0.01")

# Word lists for converting numbers to English words.
ONES = ("Zero One Two Three Four Five Six Seven Eight Nine Ten Eleven Twelve Thirteen Fourteen Fifteen "
        "Sixteen Seventeen Eighteen Nineteen").split()
# Index 0 and 1 are unused placeholders so TENS[2] is "Twenty".
TENS = "_ _ Twenty Thirty Forty Fifty Sixty Seventy Eighty Ninety".split()


# Round any value to 2 decimal places using the usual accounting rule (0.5 rounds up).
def money(x) -> Decimal:
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


# Words for 1..999, e.g. 345 -> "Three Hundred Forty Five".
def _below_1000(n: int) -> str:
    parts = []
    if n >= 100:
        parts.append(ONES[n // 100] + " Hundred")
        n %= 100
    if n >= 20:
        parts.append(TENS[n // 10] + (" " + ONES[n % 10] if n % 10 else ""))
    elif n:
        parts.append(ONES[n])
    return " ".join(parts)


# Indian numbering groups: crore (10 million), lakh (100 thousand), thousand.
def int_in_words(n: int) -> str:
    """Indian numbering: thousand, lakh (1e5), crore (1e7)."""
    if n == 0:
        return "Zero"
    parts = []
    # Peel off each unit from largest to smallest with divmod.
    for size, name in ((10**7, "Crore"), (10**5, "Lakh"), (1000, "Thousand")):
        q, n = divmod(n, size)
        if q:
            # A quotient of 1000+ (e.g. 1,000 crore) is converted recursively.
            parts.append(f"{_below_1000(q) if q < 1000 else int_in_words(q)} {name}")
    # Whatever remains is below 1000.
    if n:
        parts.append(_below_1000(n))
    return " ".join(parts)


# Convert an amount such as 123456.50 to "... Rupees and Fifty Paise Only".
def amount_in_words(amount: Decimal) -> str:
    amount = money(amount)
    # Work in integer paise to avoid floating-point errors.
    rupees, paise = divmod(int(amount * 100), 100)
    text = f"{int_in_words(rupees)} Rupees"
    if paise:
        text += f" and {int_in_words(paise)} Paise"
    return text + " Only"


# Indian financial year runs April-March: January-March belongs to the previous year's FY.
def financial_year(d: date) -> str:
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start}-{str(start + 1)[-2:]}"


# One invoice line: description, quantity, unit rate and GST percentage (default 18%).
@dataclass
class Line:
    description: str
    qty: int
    rate: Decimal
    gst_percent: Decimal = Decimal("18")


# Compute taxes for a whole invoice and return everything as a dictionary.
def build_invoice(number: int, issued: date, customer: str, customer_state: str, lines: list) -> dict:
    # Same state as the seller -> split tax into CGST + SGST; otherwise charge IGST.
    intra = customer_state.strip().lower() == SELLER["state"].lower()
    # Running totals for each tax component.
    rows, taxable_total, cgst_total, sgst_total, igst_total = [], Decimal(0), Decimal(0), Decimal(0), Decimal(0)
    for ln in lines:
        # Taxable value = rate x quantity; tax = taxable x GST%.
        taxable = money(ln.rate * ln.qty)
        tax = money(taxable * ln.gst_percent / 100)
        if intra:
            # CGST gets half; SGST gets the remainder, so the two always add up exactly to the tax (no lost paisa).
            half = money(tax / 2)
            cgst_total += half; sgst_total += tax - half
        else:
            igst_total += tax
        taxable_total += taxable
        rows.append((ln, taxable, tax))
    # Total before rounding to a whole rupee.
    raw_total = taxable_total + cgst_total + sgst_total + igst_total
    # Grand total rounded to the nearest rupee; the difference is shown as "round off".
    grand = Decimal(int(raw_total.quantize(Decimal("1"), rounding=ROUND_HALF_UP)))
    # Invoice number format: PL/<financial-year>/<4-digit sequence>, e.g. PL/2026-27/0001.
    return {"no": f"PL/{financial_year(issued)}/{number:04d}", "date": issued, "customer": customer,
            "state": customer_state, "intra": intra, "rows": rows, "taxable": taxable_total,
            "cgst": cgst_total, "sgst": sgst_total, "igst": igst_total,
            "round_off": grand - raw_total, "total": grand, "words": amount_in_words(grand)}


# Build a printable HTML invoice. Every user-supplied value goes through html.escape.
def render_html(inv: dict) -> str:
    e = html.escape
    # Table rows for the invoice lines.
    body = "".join(
        f"<tr><td>{e(l.description)}</td><td>{l.qty}</td><td>{money(l.rate)}</td><td>{l.gst_percent}%</td>"
        f"<td>{taxable}</td><td>{tax}</td></tr>" for l, taxable, tax in inv["rows"])
    # Show CGST+SGST rows for local customers or a single IGST row for others.
    taxes = (f"<tr><td>CGST</td><td>{inv['cgst']}</td></tr><tr><td>SGST</td><td>{inv['sgst']}</td></tr>"
             if inv["intra"] else f"<tr><td>IGST</td><td>{inv['igst']}</td></tr>")
    # HTML page template (CSS braces are doubled {{ }} because this is an f-string).
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Invoice {e(inv['no'])}</title>
<style>body{{font-family:Arial;margin:40px;color:#222}}h1{{color:#ff7a00}}table{{border-collapse:collapse;width:100%;margin:16px 0}}
td,th{{border:1px solid #ccc;padding:8px;text-align:left}}th{{background:#111;color:#ff7a00}}.t{{width:320px;margin-left:auto}}</style></head><body>
<h1>{e(SELLER['name'])}</h1><p>GSTIN: {e(SELLER['gstin'])} | State: {e(SELLER['state'])}</p>
<h2>Tax Invoice {e(inv['no'])}</h2><p>Date: {inv['date'].isoformat()}<br>Billed to: <b>{e(inv['customer'])}</b> ({e(inv['state'])})</p>
<table><tr><th>Description</th><th>Qty</th><th>Rate</th><th>GST</th><th>Taxable</th><th>Tax</th></tr>{body}</table>
<table class="t"><tr><td>Taxable value</td><td>{inv['taxable']}</td></tr>{taxes}
<tr><td>Round off</td><td>{inv['round_off']}</td></tr><tr><th>Total (INR)</th><th>{inv['total']}</th></tr></table>
<p><b>Amount in words:</b> {e(inv['words'])}</p><p>Thank you for learning with PythonLife.</p></body></html>"""


# Demo with assertions; with --write the sample invoice is saved in the current folder.
def demo(write_to: str | None = None) -> None:
    # Amount-in-words checks: thousands, lakh, zero and crore.
    assert amount_in_words(Decimal("11800")) == "Eleven Thousand Eight Hundred Rupees Only"
    assert amount_in_words(Decimal("123456.50")) == "One Lakh Twenty Three Thousand Four Hundred Fifty Six Rupees and Fifty Paise Only"
    assert amount_in_words(Decimal("0")) == "Zero Rupees Only"
    assert amount_in_words(Decimal("12345678")) == "One Crore Twenty Three Lakh Forty Five Thousand Six Hundred Seventy Eight Rupees Only"
    # Financial year boundary: 31 Mar 2026 is still FY 2025-26, 1 Apr 2026 starts 2026-27.
    assert financial_year(date(2026, 3, 31)) == "2025-26" and financial_year(date(2026, 4, 1)) == "2026-27"
    # Same-state customer: 18% GST on 10,000 = 1,800, split into 900 + 900.
    items = [Line("Python Full Course (Telugu)", 1, Decimal("10000"))]
    local = build_invoice(1, date(2026, 11, 13), "Ravi <Kumar>", "Telangana", items)
    assert local["no"] == "PL/2026-27/0001" and local["cgst"] == local["sgst"] == Decimal("900.00") and local["igst"] == 0
    assert local["total"] == Decimal("11800")
    # Other-state customer: a single IGST of 1,800.
    other = build_invoice(2, date(2026, 11, 13), "Anil", "Karnataka", items)
    assert other["igst"] == Decimal("1800.00") and other["cgst"] == 0 and other["total"] == Decimal("11800")
    # Awkward amount that needs rounding: the books must still balance exactly.
    odd = build_invoice(3, date(2026, 11, 13), "Sita", "Telangana", [Line("Workshop", 3, Decimal("333.33"))])
    assert odd["total"] == odd["taxable"] + odd["cgst"] + odd["sgst"] + odd["round_off"]
    # A hostile customer name must be escaped in the page.
    page = render_html(local)
    assert "Ravi &lt;Kumar&gt;" in page and "<Kumar>" not in page
    # Save to the requested folder, or to a temporary folder when not asked.
    out = Path(write_to or tempfile.mkdtemp()) / "sample_invoice.html"
    out.write_text(page, encoding="utf-8")
    print("invoice written:", out)
    print("PythonLife GST invoice demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo("." if "--write" in sys.argv else None)
