#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 07 - Student Review Sentiment Analyzer
=========================================================
WHAT IT DOES
    Scores student reviews as positive / neutral / negative with a lexicon-based
    model that understands NEGATION ("not good"), INTENSIFIERS ("very good") and
    common Telugu-English words ("chala bagundi" = "very good"). Produces a rating
    breakdown and the words students praise or complain about most.

WHAT YOU LEARN
    tokenising text, rule-based NLP, score normalisation, collections.Counter.
    No machine-learning libraries needed - the logic is fully explainable.

USAGE
    python app.py                 # demo with sample reviews and assertions
    python app.py reviews.txt     # one review per line
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# math.sqrt squashes the score, re tokenises text, Counter counts words.
import math
import re
import sys
from collections import Counter

# Sentiment lexicon: word -> strength. Positive numbers are praise, negatives are complaints.
# Includes Telugu-English words such as "bagundi" (it is good).
LEXICON = {
    "good": 2, "great": 3, "excellent": 3.5, "amazing": 3.5, "awesome": 3, "best": 3, "super": 3,
    "helpful": 2, "clear": 1.5, "easy": 1.5, "love": 3, "loved": 3, "useful": 2, "perfect": 3.5,
    "bagundi": 2, "baagundi": 2, "baga": 1.5, "nice": 2, "supportive": 2, "practical": 1.5, "recommend": 2.5,
    "bad": -2, "poor": -2.5, "boring": -2, "confusing": -2, "waste": -3, "worst": -3.5, "slow": -1.5,
    "difficult": -1, "hard": -1, "late": -1.5, "useless": -3, "terrible": -3.5, "disappointed": -2.5,
}
# Boosters strengthen the next sentiment word ("very good"); chala = "very" in Telugu.
BOOSTERS = {"very": 1.5, "really": 1.5, "extremely": 2.0, "chala": 1.5, "too": 1.3, "so": 1.3}
# Negators flip meaning ("not good"). Both apostrophe and no-apostrophe spellings are covered.
NEGATORS = {"not", "no", "never", "cannot", "isnt", "isn't", "wasnt", "wasn't", "dont", "don't", "didnt", "didn't"}
# Words ignored when listing most-praised / most-complained topics.
STOP = {"not", "no", "the", "a", "an", "and", "is", "was", "are", "to", "of", "in", "for", "i", "it", "this", "my", "me", "we",
        "with", "on", "at", "that", "very", "really", "so", "too", "chala", "course", "classes", "class"}
# A token is a run of lower-case letters or apostrophes.
TOKEN = re.compile(r"[a-z']+")


# Score one review between -1 (very negative) and +1 (very positive).
def score_review(text: str) -> float:
    """Return a compound score in (-1, 1)."""
    toks = TOKEN.findall(text.lower())
    total = 0.0
    for i, t in enumerate(toks):
        if t not in LEXICON:
            continue
        s = LEXICON[t]
        # If the previous word is a booster, multiply the word's strength.
        if i > 0 and toks[i - 1] in BOOSTERS:
            s *= BOOSTERS[toks[i - 1]]
        # A negator in the previous 3 words flips the sign and weakens it slightly (-0.8).
        if any(p in NEGATORS for p in toks[max(0, i - 3):i]):
            s *= -0.8
        total += s
    # Squash the total into (-1, 1) with x / sqrt(x^2 + 15), the same idea VADER uses.
    return total / math.sqrt(total * total + 15)       # squash like VADER


# Convert a score to a label with a neutral zone between -0.2 and +0.2.
def label(score: float) -> str:
    return "positive" if score >= 0.2 else "negative" if score <= -0.2 else "neutral"


# Analyse many reviews: label counts, average score, and the most common words in positive vs negative reviews.
def analyze(reviews: list) -> dict:
    scored = [(r, score_review(r)) for r in reviews]
    labels = Counter(label(s) for _, s in scored)
    pos_words, neg_words = Counter(), Counter()
    for r, s in scored:
        # Candidate topic words: not stop words, not sentiment words, longer than 2 letters.
        words = [w for w in TOKEN.findall(r.lower()) if w not in STOP and w not in LEXICON and len(w) > 2]
        # Choose which counter to update: praised, complained, or a throw-away Counter for neutral reviews.
        (pos_words if s >= 0.2 else neg_words if s <= -0.2 else Counter()).update(words)
    return {"labels": labels, "average": sum(s for _, s in scored) / len(scored), "scored": scored,
            "praised": pos_words.most_common(5), "complaints": neg_words.most_common(5)}


# Sample reviews used by the demo.
SAMPLE = [
    "Chala bagundi! The trainer explains every concept very clearly.",
    "Best Python course in Telugu, really practical projects.",
    "Not good. Classes started late and audio was poor.",
    "The course is okay, nothing special.",
    "Super support from the trainer, I would recommend it to everyone.",
    "Videos are boring and confusing, waste of time.",
    "Easy to follow and the projects are useful.",
    "Not bad at all, projects were helpful.",
]


# Demo with assertions.
def demo() -> None:
    r = analyze(SAMPLE)
    for text, s in r["scored"]:
        print(f"{s:+.2f} {label(s):<8} {text}")
    print("Summary:", dict(r["labels"]), f"avg={r['average']:+.2f}")
    print("Praised:", r["praised"], " Complaints:", r["complaints"])
    # Plain and negated sentiment.
    assert label(score_review("good")) == "positive" and label(score_review("not good")) == "negative"
    # A booster raises the score ("very good" > "good").
    assert score_review("very good") > score_review("good") > 0
    # Double negative: "not bad" is positive.
    assert score_review("not bad at all") > 0                 # negated negative becomes positive
    # Mixed English/Telugu positive review and a clearly negative review.
    assert label(score_review(SAMPLE[0])) == "positive" and label(score_review(SAMPLE[5])) == "negative"
    # No sentiment words -> neutral.
    assert label(score_review(SAMPLE[3])) == "neutral"
    # At least 4 positive and 2 negative reviews in the sample.
    assert r["labels"]["positive"] >= 4 and r["labels"]["negative"] >= 2
    print("PythonLife review sentiment demo OK")


# CLI: pass a text file (one review per line) or run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as f:
            # Read non-empty lines (the loop variable l is a line of text).
            lines = [l.strip() for l in f if l.strip()]
        res = analyze(lines)
        print(dict(res["labels"]), f"avg={res['average']:+.2f}", res["praised"], res["complaints"])
    else:
        demo()
