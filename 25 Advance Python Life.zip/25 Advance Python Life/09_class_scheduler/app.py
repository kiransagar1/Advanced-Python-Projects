#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 09 - Batch Timetable Scheduler (conflicts + calendar export)
===============================================================================
WHAT IT DOES
    Manages weekly class sessions for live batches. It detects TRAINER and ROOM
    clashes, finds free slots for a trainer, and exports an .ics calendar file with
    weekly recurrence that students can import into Google/Apple/Outlook Calendar.

WHAT YOU LEARN
    interval-overlap logic, sorting + sweep over time ranges, datetime/timedelta,
    the iCalendar (RFC 5545) text format with RRULE, dataclasses.

USAGE
    python app.py        # demo with assertions; prints the generated .ics
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# uuid makes unique calendar event ids; datetime tools build the .ics timestamps.
import uuid
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone

# Weekday names indexed 0 (Monday) to 6 (Sunday), matching date.weekday().
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# Convert "HH:MM" to minutes since midnight so times can be compared with plain integers.
def minutes(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


# Convert minutes since midnight back to "HH:MM".
def hhmm(mins: int) -> str:
    return f"{mins // 60:02d}:{mins % 60:02d}"


# A weekly class session. frozen=True makes it immutable and safe to share.
@dataclass(frozen=True)
class Session:
    title: str
    trainer: str
    room: str
    weekday: int       # 0 = Monday
    start: str         # "HH:MM"
    end: str

    # Validate on creation: a class must end after it starts.
    def __post_init__(self):
        if minutes(self.end) <= minutes(self.start):
            raise ValueError(f"{self.title}: end must be after start")

    # Two sessions overlap when they are on the same day and each starts before the other ends.
    def overlaps(self, other: "Session") -> bool:
        # Strict < comparisons mean back-to-back classes do not clash.
        """Half-open intervals: 10:00-11:00 and 11:00-12:00 do NOT clash."""
        return (self.weekday == other.weekday
                and minutes(self.start) < minutes(other.end) and minutes(other.start) < minutes(self.end))


# Check every pair of sessions once and report the kind of clash (trainer and/or room).
def find_conflicts(sessions: list) -> list:
    out = []
    for i, a in enumerate(sessions):
        # sessions[i + 1:] avoids comparing a pair twice or a session with itself.
        for b in sessions[i + 1:]:
            if a.overlaps(b):
                if a.trainer == b.trainer:
                    out.append((a, b, "trainer"))
                if a.room == b.room:
                    out.append((a, b, "room"))
    return out


# Find the free gaps in one trainer's day.
def free_slots(sessions: list, trainer: str, weekday: int, day_start="09:00", day_end="21:00", min_minutes=60):
    """Gaps (start, end) in the trainer's day that are at least min_minutes long."""
    # The trainer's busy intervals, sorted by start time.
    busy = sorted((minutes(s.start), minutes(s.end)) for s in sessions if s.trainer == trainer and s.weekday == weekday)
    # cursor = end of the last busy block seen so far.
    cursor, end, gaps = minutes(day_start), minutes(day_end), []
    for s, e in busy:
        # A gap before the next class that is long enough is a free slot.
        if s - cursor >= min_minutes:
            gaps.append((hhmm(cursor), hhmm(s)))
        # max() handles overlapping classes: the cursor never moves backwards.
        cursor = max(cursor, e)
    # Check the gap after the last class until the end of the working day.
    if end - cursor >= min_minutes:
        gaps.append((hhmm(cursor), hhmm(end)))
    return gaps


# Export sessions as an iCalendar (.ics) file importable into Google/Apple/Outlook calendars.
def to_ics(sessions: list, first_day: date, weeks: int) -> str:
    """Weekly recurring events starting on the first matching weekday on/after first_day."""
    # DTSTAMP = creation time in UTC, required by the iCalendar format.
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//PythonLife//Timetable//EN", "CALSCALE:GREGORIAN"]
    for s in sessions:
        # First date on or after first_day that falls on this session's weekday.
        d = first_day + timedelta(days=(s.weekday - first_day.weekday()) % 7)
        # divmod(minutes, 60) gives (hours, minutes) for time().
        start = datetime.combine(d, time(*divmod(minutes(s.start), 60)))
        end = datetime.combine(d, time(*divmod(minutes(s.end), 60)))
        # One VEVENT per session; UID must be globally unique; RRULE repeats it weekly for `weeks` weeks.
        lines += ["BEGIN:VEVENT", f"UID:{uuid.uuid4()}@pythonlife", f"DTSTAMP:{stamp}",
                  f"DTSTART:{start:%Y%m%dT%H%M%S}", f"DTEND:{end:%Y%m%dT%H%M%S}",
                  f"RRULE:FREQ=WEEKLY;COUNT={weeks}", f"SUMMARY:{s.title}",
                  f"LOCATION:{s.room}", f"DESCRIPTION:Trainer: {s.trainer}", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    # iCalendar requires CRLF (\r\n) line endings.
    return "\r\n".join(lines) + "\r\n"          # the spec requires CRLF line endings


# Demo with assertions.
def demo() -> None:
    sessions = [
        # Sample timetable with deliberate clashes.
        Session("Python Batch 12", "Kiran", "Room A", 0, "10:00", "11:30"),
        Session("Oracle SQL Batch 4", "Kiran", "Room B", 0, "11:00", "12:00"),   # trainer clash
        Session("Java Batch 7", "Sunita", "Room A", 0, "11:00", "12:00"),        # room clash
        Session("Python Q&A", "Kiran", "Room A", 0, "11:30", "12:30"),           # back-to-back with batch 12: OK
        Session("Weekend Python", "Kiran", "Room A", 5, "09:00", "12:00"),
    ]
    # Run the conflict detector and print every clash.
    conflicts = find_conflicts(sessions)
    for a, b, kind in conflicts:
        print(f"CONFLICT ({kind}): {a.title} <-> {b.title} on {DAYS[a.weekday]}")
    kinds = sorted((a.title, b.title, k) for a, b, k in conflicts)
    # Same trainer at overlapping times is detected.
    assert ("Python Batch 12", "Oracle SQL Batch 4", "trainer") in kinds
    # Same room at overlapping times is detected.
    assert ("Python Batch 12", "Java Batch 7", "room") in kinds
    # Back-to-back sessions (11:30 end / 11:30 start) must NOT be flagged.
    assert not any("Q&A" in a.title and "Batch 12" in b.title for a, b, _ in conflicts)
    # Kiran's Monday is busy 10:00-12:30, so the free gaps are 09:00-10:00 and 12:30-21:00.
    gaps = free_slots(sessions, "Kiran", 0)
    print("Kiran free on Monday:", gaps)
    assert gaps[0] == ("09:00", "10:00") and gaps[-1] == ("12:30", "21:00")
    # Export two sessions repeating weekly for 8 weeks.
    ics = to_ics(sessions[:2], date(2026, 11, 13), weeks=8)
    assert ics.count("BEGIN:VEVENT") == 2 and "RRULE:FREQ=WEEKLY;COUNT=8" in ics and "\r\n" in ics
    assert "DTSTART:20261116T100000" in ics          # first Monday on/after Fri 13 Nov 2026
    # Invalid session (end before start) must raise ValueError.
    try:
        Session("bad", "x", "y", 0, "12:00", "11:00"); raise AssertionError
    except ValueError:
        pass
    print("PythonLife scheduler demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo()
