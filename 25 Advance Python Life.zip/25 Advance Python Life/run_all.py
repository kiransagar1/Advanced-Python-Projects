#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""PythonLife - run every project's self-checking demo and print a pass/fail table.

Usage:  python run_all.py            (exit code 0 only if all 25 pass)
"""
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).parent
projects = sorted(p for p in root.iterdir() if p.is_dir() and (p / "app.py").exists())
failed = 0
print(f"{'Project':<32}{'Result':<8}{'Time':>6}")
for p in projects:
    t = time.time()
    try:
        # Make the child print UTF-8 and read it back as UTF-8. Without this, Windows decodes the output
        # with its legacy code page (cp1252) and crashes on Telugu text (UnicodeDecodeError).
        env = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}
        r = subprocess.run([sys.executable, "app.py"], cwd=p, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", env=env, timeout=120)
        out, err = r.stdout or "", r.stderr or ""          # never None, even if decoding had problems
        ok = r.returncode == 0 and "demo OK" in out
        detail = "" if ok else (err.strip().splitlines() or ["no 'demo OK' line"])[-1]
    except subprocess.TimeoutExpired:
        ok, detail = False, "timeout"
    failed += not ok
    print(f"{p.name:<32}{'PASS' if ok else 'FAIL':<8}{time.time() - t:>5.1f}s  {detail}")
print(f"\n{len(projects) - failed}/{len(projects)} projects passed")
sys.exit(1 if failed else 0)
