#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 14 - Async Website Link Checker
==================================================
WHAT IT DOES
    Crawls a website starting from one URL and checks EVERY link (same-site pages
    are followed, external links are only checked) concurrently with asyncio.
    Reports broken links (404/500/timeouts) so you can fix them before students find them.

WHAT YOU LEARN
    asyncio (gather, Semaphore, to_thread), breadth-first crawling, URL joining and
    de-duplication, spinning up a local test server so the demo works offline.

USAGE
    python app.py                       # demo against a local test site (with assertions)
    python app.py https://example.com   # crawl a real site (max 50 pages)
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# asyncio runs many checks concurrently; urllib fetches pages; threading + http.server host the local demo site.
import asyncio
import sys
import threading
import urllib.error
import urllib.request
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urldefrag, urljoin, urlparse


# Collects every <a href> from an HTML page.
class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            href = dict(attrs).get("href")
            if href:
                self.links.append(href)


# Turn raw hrefs into clean absolute http(s) URLs.
def extract_links(html_text: str, base: str) -> list:
    p = LinkParser()
    p.feed(html_text)
    out = []
    for href in p.links:
        # urljoin resolves relative links against the page URL; urldefrag drops #fragments so /about#team and /about are the same page.
        url = urldefrag(urljoin(base, href.strip()))[0]
        # Ignore mailto:, tel:, javascript: and other non-web links.
        if urlparse(url).scheme in ("http", "https"):
            out.append(url)
    return out


# Fetch a URL with the standard library. It blocks, so the crawler runs it in worker threads.
def fetch(url: str, timeout: float = 5.0) -> tuple:
    """Blocking fetch (run in a worker thread). Returns (status, html_or_empty)."""
    # Identify the crawler politely with a User-Agent header.
    req = urllib.request.Request(url, headers={"User-Agent": "PythonLife-LinkChecker/1.0"})
    try:
        # Local test servers must not go through a system proxy; real websites still use it.
        local = urlparse(url).hostname in ("127.0.0.1", "localhost", "::1")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if local else urllib.request.build_opener()
        with opener.open(req, timeout=timeout) as resp:
            body = ""
            # Only read the body of HTML pages (max ~300 KB); we need it only to find more links.
            if "text/html" in resp.headers.get("Content-Type", ""):
                body = resp.read(300_000).decode("utf-8", errors="replace")
            return resp.status, body
    # HTTP errors (404, 500...) still carry a status code we can report.
    except urllib.error.HTTPError as e:
        return e.code, ""
    # Network problems (DNS failure, timeout, refused) are reported as text like "ERR TimeoutError".
    except Exception as e:                                    # DNS errors, timeouts, refused ...
        return f"ERR {type(e).__name__}", ""


# Breadth-first crawl: check each level of pages concurrently, then follow the links found.
async def crawl(start: str, max_pages: int = 50, concurrency: int = 8) -> dict:
    # Semaphore limits how many requests run at the same time (be gentle with the server).
    sem = asyncio.Semaphore(concurrency)
    host = urlparse(start).netloc
    # results = url -> status; seen = every URL queued so far (prevents loops); frontier = URLs to check next.
    results, seen, frontier = {}, {start}, [start]

    # Run the blocking fetch() in a thread without freezing the event loop.
    async def check(url):
        async with sem:
            return await asyncio.to_thread(fetch, url)

    while frontier:
        # Take the current batch and start a fresh frontier for newly discovered links.
        batch, frontier = frontier, []
        # asyncio.gather checks the whole batch at the same time and keeps results in order.
        for url, (status, body) in zip(batch, await asyncio.gather(*(check(u) for u in batch))):
            results[url] = status
            # Follow links only from pages on the same website; external links are checked but not crawled.
            if body and urlparse(url).netloc == host:           # follow only same-site pages
                for link in extract_links(body, url):
                    # Respect max_pages for the site's own pages (external links are still checked).
                    if link not in seen and (len(seen) < max_pages or urlparse(link).netloc != host):
                        seen.add(link)
                        frontier.append(link)
    return results


# Broken = no numeric status (network error) or an HTTP status of 400 or above.
def broken(results: dict) -> dict:
    return {u: s for u, s in results.items() if not isinstance(s, int) or s >= 400}


# Local test site so the demo needs no internet connection.
# ---- local test site (so the demo needs no internet) -------------------------------------
PAGES = {
    "/": '<a href="/a">A</a> <a href="/b">B</a> <a href="/missing">gone</a> <a href="/about#team">About</a>',
    "/a": '<a href="/">home</a> <a href="/deep">deep</a> <a href="mailto:x@y.z">mail</a>',
    "/b": '<a href="/error500">boom</a> <a href="/a">A again</a>',
    "/about": "<p>About us</p>", "/deep": "<p>Deep page</p>",
}


# A minimal web server serving the pages above (plus a deliberate 500 error and 404s).
class Site(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/error500":
            code, body = 500, "server error"
        elif path in PAGES:
            code, body = 200, PAGES[path]
        else:
            code, body = 404, "not found"
        data = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # Silence the server's per-request log lines.
    def log_message(self, *args):
        pass


# Demo: start the server on a free port, crawl it, and assert exactly which links are broken.
def demo() -> None:
    # Port 0 asks the operating system for any free port.
    server = ThreadingHTTPServer(("127.0.0.1", 0), Site)
    # Run the server in a background daemon thread.
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    try:
        results = asyncio.run(crawl(base + "/"))
    # Always stop the server, even if the crawl fails.
    finally:
        server.shutdown()
    for url, status in sorted(results.items()):
        print(f"{status}  {url.replace(base, '') or '/'}")
    bad = {u.replace(base, ""): s for u, s in broken(results).items()}
    # Exactly two broken links: /missing (404) and /error500 (500).
    assert bad == {"/missing": 404, "/error500": 500}, bad
    assert results[base + "/deep"] == 200 and results[base + "/about"] == 200
    # Seven unique URLs, each checked once - no duplicates despite pages linking to each other.
    assert len(results) == 7                                   # / a b missing about deep error500 (no duplicates)
    print("PythonLife async link checker demo OK")


# CLI: pass a start URL, or run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = asyncio.run(crawl(sys.argv[1]))
        bad = broken(res)
        print(f"Checked {len(res)} URLs, {len(bad)} broken")
        for u, s in bad.items():
            print(" ", s, u)
    else:
        demo()
