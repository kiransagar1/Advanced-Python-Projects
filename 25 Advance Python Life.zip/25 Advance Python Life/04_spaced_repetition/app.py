#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 04 - Spaced Repetition Flashcards (SM-2)
===========================================================
WHAT IT DOES
    Flashcards that show up exactly when you are about to forget them, using the
    SuperMemo-2 algorithm. Ships with a sample English -> Telugu programming
    glossary, saves progress to JSON, and can run an interactive review.

WHAT YOU LEARN
    The SM-2 algorithm, dataclasses, JSON persistence with Unicode (Telugu),
    simulating time with a plain integer "day" so the logic is testable.

USAGE
    python app.py            # 30-day simulation with assertions
    python app.py --review   # review today's due cards (progress.json is saved)
Rate each card 0-5: 0-2 = forgot, 3 = hard, 4 = good, 5 = easy.
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# json stores the deck on disk; os checks whether a progress file exists; random drives the simulation.
import json
import os
import random
import sys
from dataclasses import asdict, dataclass

# Some Windows terminals default to a legacy encoding; switch to UTF-8 so Telugu prints correctly.
try:  # make Telugu print correctly on terminals that default to a legacy encoding
    sys.stdout.reconfigure(encoding="utf-8")
# Older streams may not support reconfigure(); ignoring the error is fine here.
except Exception:
    pass


# A flashcard plus its SM-2 scheduling state.
@dataclass
class Card:
    front: str
    back: str
    # ease = how quickly the interval grows (starts at 2.5, never below 1.3).
    ease: float = 2.5
    interval: int = 0     # days until next review
    reps: int = 0         # successful reviews in a row
    due: int = 0          # absolute day number


# SM-2 algorithm: update one card after a review. quality 0-2 = forgot, 3 = hard, 4 = good, 5 = easy.
def review(card: Card, quality: int, today: int) -> Card:
    """Apply one SM-2 update. quality is an integer 0..5."""
    # Reject ratings outside 0..5.
    if not 0 <= quality <= 5:
        raise ValueError("quality must be between 0 and 5")
    # Forgot the card: restart the ladder with a 1-day interval.
    if quality < 3:                       # forgot: start the ladder again
        card.reps, card.interval = 0, 1
    else:
        # Interval ladder: 1 day, then 6 days, then previous interval x ease.
        card.interval = 1 if card.reps == 0 else 6 if card.reps == 1 else round(card.interval * card.ease)
        card.reps += 1
    # Adjust ease: easy answers raise it, hard ones lower it, floor 1.3.
    card.ease = max(1.3, card.ease + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
    # Schedule the next review: today + interval (days are plain integers).
    card.due = today + card.interval
    return card


# A collection of cards that can be filtered by due date and saved/loaded as JSON.
class Deck:
    def __init__(self, cards=None):
        self.cards = list(cards or [])

    # Cards whose due day has arrived (or passed).
    def due(self, today: int) -> list:
        return [c for c in self.cards if c.due <= today]

    # ensure_ascii=False keeps Telugu readable in the file instead of \u escapes.
    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump([asdict(c) for c in self.cards], f, ensure_ascii=False, indent=2)

    # Alternative constructor: build a Deck from a saved JSON file.
    @classmethod
    def load(cls, path: str) -> "Deck":
        with open(path, encoding="utf-8") as f:
            # Rebuild each Card from its saved dictionary of fields.
            return cls(Card(**row) for row in json.load(f))


# Sample English -> Telugu programming glossary (with transliteration in brackets).
GLOSSARY = [  # sample cards - edit / extend freely
    ("Variable", "చరరాశి (chararaasi)"), ("Function", "ప్రమేయం (prameyam)"),
    ("Loop", "పునరావృతం (punaraavartam)"), ("Condition", "షరతు (sharatu)"),
    ("List", "జాబితా (jaabitaa)"), ("Dictionary", "నిఘంటువు (nighantuvu)"),
]


# A fresh deck made from the glossary.
def default_deck() -> Deck:
    return Deck(Card(f, b) for f, b in GLOSSARY)


# Simulate a learner over several days with a fixed random seed (repeatable results).
def simulate(days: int = 30, recall: float = 0.8, seed: int = 7) -> Deck:
    rng = random.Random(seed)
    deck, reviews = default_deck(), 0
    # Walk through each day and review every card that is due.
    for day in range(days):
        for card in deck.due(day):
            # Recall succeeds with probability `recall` (rating 4), otherwise fails (rating 2).
            review(card, 4 if rng.random() < recall else 2, day)
            reviews += 1
    # Show how many reviews spaced repetition needed versus reviewing every card every day.
    print(f"{days} days, {reviews} reviews for {len(deck.cards)} cards "
          f"(naive daily review would need {days * len(deck.cards)})")
    return deck


# Real review session: load saved progress (or start fresh) and review today's due cards.
def interactive(path: str = "progress.json") -> None:
    deck = Deck.load(path) if os.path.exists(path) else default_deck()
    # Today as a day number: Unix seconds divided by 86,400 seconds per day.
    today = int(__import__("time").time() // 86400)
    due = deck.due(today)
    print(f"{len(due)} card(s) due today")
    for c in due:
        input(f"\n{c.front}  (press Enter to reveal)")
        print("->", c.back)
        # Read a rating, clamp it into 0..5 (blank input counts as 0) and update the card.
        review(c, max(0, min(5, int(input("Rate 0-5: ") or 0))), today)
    # Persist the updated schedule.
    deck.save(path)


# Demo with assertions.
def demo() -> None:
    deck = simulate()
    # Every card was reviewed at least once.
    assert all(c.reps > 0 for c in deck.cards)
    # After successful reviews the interval must have grown to 6+ days.
    assert max(c.interval for c in deck.cards) >= 6          # intervals grow
    # A perfect first review: 1-day interval, due tomorrow, ease increases.
    c = review(Card("x", "y"), 5, 0); assert (c.interval, c.due) == (1, 1) and c.ease > 2.5
    # A failed review resets repetitions and the interval.
    c = review(Card("x", "y", reps=5, interval=20), 1, 10); assert (c.reps, c.interval) == (0, 1)
    import tempfile
    # Save and reload in a temporary folder.
    with tempfile.TemporaryDirectory() as tmp:
        p = os.path.join(tmp, "p.json"); deck.save(p)
        assert Deck.load(p).cards[0].back == deck.cards[0].back   # Telugu survives round-trip
    print("PythonLife spaced-repetition demo OK")


# Entry point: --review for real use, otherwise the demo.
if __name__ == "__main__":
    interactive() if "--review" in sys.argv else demo()
