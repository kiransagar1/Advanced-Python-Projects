#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 20 - Rate Limiter Toolkit (Token Bucket + Sliding Window)
============================================================================
WHAT IT DOES
    Protects APIs and login forms from abuse. Includes:
      * TokenBucket        - allows bursts, refills steadily (like most public APIs)
      * SlidingWindowLog   - exact "N requests per T seconds"
      * KeyedLimiter       - separate limits per user / IP address
      * @rate_limited      - decorator that raises RateLimitExceeded with retry_after
    All use an injectable clock, so tests run instantly and deterministically.

WHAT YOU LEARN
    algorithms behind rate limiting, time-based state, deque, thread locks,
    dependency injection for testability, custom exceptions.

USAGE
    python app.py        # demo with assertions
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# threading.Lock makes limiters safe across threads, deque is a fast queue, wraps keeps function metadata.
import threading
import time
from collections import deque
from functools import wraps


# Raised when a call is blocked; retry_after says how many seconds to wait.
class RateLimitExceeded(Exception):
    def __init__(self, retry_after: float):
        super().__init__(f"rate limit exceeded, retry after {retry_after:.2f}s")
        self.retry_after = retry_after


# Token bucket: allows short bursts (up to `capacity`) while limiting the long-run average to `rate` per second.
class TokenBucket:
    """Holds up to `capacity` tokens and refills `rate` tokens per second."""

    # clock is injectable (default: monotonic time, which never goes backwards) so tests can fake time.
    def __init__(self, rate: float, capacity: float, clock=time.monotonic):
        self.rate, self.capacity, self.clock = rate, capacity, clock
        # The bucket starts full.
        self.tokens, self.last, self._lock = float(capacity), clock(), threading.Lock()

    # Add the tokens earned since the last check, never exceeding the capacity.
    def _refill(self) -> None:
        now = self.clock()
        self.tokens = min(self.capacity, self.tokens + (now - self.last) * self.rate)
        self.last = now

    # Try to spend `cost` tokens; True means the request is allowed.
    def allow(self, cost: float = 1) -> bool:
        with self._lock:
            self._refill()
            if self.tokens >= cost:
                self.tokens -= cost
                return True
            return False

    # Seconds until enough tokens will be available again.
    def retry_after(self, cost: float = 1) -> float:
        with self._lock:
            self._refill()
            return max(0.0, (cost - self.tokens) / self.rate)


# Sliding-window log: remembers the timestamp of every allowed event for an exact "N per T seconds" rule.
class SlidingWindowLog:
    """At most `limit` events in any window of `window` seconds (exact, uses O(limit) memory)."""

    def __init__(self, limit: int, window: float, clock=time.monotonic):
        self.limit, self.window, self.clock = limit, window, clock
        # deque of timestamps, oldest on the left.
        self.events, self._lock = deque(), threading.Lock()

    # Forget events that have slid out of the window.
    def _expire(self, now: float) -> None:
        while self.events and self.events[0] <= now - self.window:
            self.events.popleft()

    def allow(self, cost: float = 1) -> bool:
        with self._lock:
            now = self.clock()
            self._expire(now)
            # Allowed only while fewer than `limit` events remain in the window.
            if len(self.events) < self.limit:
                self.events.append(now)
                return True
            return False

    def retry_after(self, cost: float = 1) -> float:
        with self._lock:
            now = self.clock()
            self._expire(now)
            # The oldest event leaves the window at (its time + window), so that is when to retry.
            return 0.0 if len(self.events) < self.limit else self.events[0] + self.window - now


# Keyed limiter: a separate, independent limiter for every key (user, IP address, API key ...).
class KeyedLimiter:
    """One independent limiter per key (user id, IP ...). `factory` builds a new limiter."""

    def __init__(self, factory):
        self.factory, self.limiters, self._lock = factory, {}, threading.Lock()

    def get(self, key):
        with self._lock:
            # setdefault creates the limiter on first use; the lock prevents two threads creating two.
            return self.limiters.setdefault(key, self.factory())

    def allow(self, key, cost: float = 1) -> bool:
        return self.get(key).allow(cost)


# Decorator: turns any function into a rate-limited one.
def rate_limited(limiter):
    """Decorator: raise RateLimitExceeded when the (shared) limiter says no."""
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            # Blocked: raise an exception that tells the caller how long to wait.
            if not limiter.allow():
                raise RateLimitExceeded(limiter.retry_after())
            return fn(*a, **kw)
        return wrapper
    return deco


# Fake clock so the demo can jump forward in time instantly.
class FakeClock:
    def __init__(self): self.t = 100.0
    def __call__(self): return self.t
    def advance(self, s): self.t += s


# Demo with assertions.
def demo() -> None:
    clk = FakeClock()
    # Bucket: 1 token/second, capacity 5.
    tb = TokenBucket(rate=1, capacity=5, clock=clk)
    # A burst of 5 passes and the 6th is blocked.
    assert [tb.allow() for _ in range(6)] == [True] * 5 + [False]          # burst of 5, then blocked
    assert abs(tb.retry_after() - 1.0) < 1e-9
    # After 2 seconds two tokens are back.
    clk.advance(2)
    assert [tb.allow() for _ in range(3)] == [True, True, False]           # 2 tokens refilled
    # A long idle period refills the bucket only up to its capacity (5), not 1000.
    clk.advance(1000)
    assert sum(tb.allow() for _ in range(10)) == 5                         # never exceeds capacity

    # Sliding window: 3 requests per 10 seconds.
    sw = SlidingWindowLog(limit=3, window=10, clock=clk)
    assert [sw.allow() for _ in range(4)] == [True, True, True, False]
    assert abs(sw.retry_after() - 10) < 1e-9
    # After the window passes, old events have expired.
    clk.advance(10)
    assert sw.allow()                                                      # old events expired

    # Each user gets their own limit of 2 requests per minute.
    per_user = KeyedLimiter(lambda: SlidingWindowLog(2, 60, clock=clk))
    assert [per_user.allow("alice") for _ in range(3)] == [True, True, False]
    assert per_user.allow("bob")                                           # bob has his own budget

    # Decorator in action: 2 OTP messages allowed, the third is blocked.
    @rate_limited(TokenBucket(rate=0.5, capacity=2, clock=clk))
    def send_otp(phone):
        return f"OTP sent to {phone}"

    assert send_otp("9999") and send_otp("9999")
    try:
        send_otp("9999"); raise AssertionError("third call must be blocked")
    except RateLimitExceeded as e:
        print("blocked:", e)
        # 0.5 tokens/second, empty bucket -> must wait 2 seconds for the next token.
        assert abs(e.retry_after - 2.0) < 1e-9
    print("PythonLife rate limiter demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo()
