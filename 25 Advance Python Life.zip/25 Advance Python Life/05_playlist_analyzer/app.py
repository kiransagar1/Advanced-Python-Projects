#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 05 - Course Playlist Analyzer & Study Planner
================================================================
WHAT IT DOES
    Reads a CSV export of a video playlist (title,duration,views), reports total
    watch time, longest/shortest and most-viewed videos, and builds a day-by-day
    study plan that fits your daily time budget WITHOUT splitting a video.

WHAT YOU LEARN
    csv + io, regular expressions, greedy bin-packing in order, formatting time,
    generating realistic test data with a seeded random generator.

USAGE
    python app.py                                          # demo: 101-video sample playlist
    python app.py playlist.csv --minutes-per-day 90
CSV durations can be SS, MM:SS or HH:MM:SS.
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# csv reads/writes the playlist, io.StringIO treats text as a file, re parses durations.
import csv
import io
import random
import re
import sys

# Accepts H:MM:SS / M:SS (groups 1-3) or a plain number of seconds (group 4).
DUR = re.compile(r"^\s*(?:(\d+):)?(\d{1,2}):(\d{2})\s*$|^\s*(\d+)\s*$")


# Convert a duration string to seconds.
def parse_duration(text: str) -> int:
    """'1:02:03' -> 3723, '12:30' -> 750, '45' -> 45 (seconds)."""
    m = DUR.match(text)
    if not m:
        raise ValueError(f"bad duration: {text!r}")
    # Plain seconds, e.g. "45".
    if m.group(4):
        return int(m.group(4))
    # Hours are optional; minutes and seconds are always present.
    h, mi, s = int(m.group(1) or 0), int(m.group(2)), int(m.group(3))
    # Reject impossible values such as 12:75 (seconds > 59, or minutes > 59 when hours are given).
    if s > 59 or (h and mi > 59):
        raise ValueError(f"bad duration: {text!r}")
    return h * 3600 + mi * 60 + s


# Format seconds as "1h 02m 03s" (hours hidden when zero).
def fmt(seconds: int) -> str:
    # divmod returns (quotient, remainder) in a single step.
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}h {m:02d}m {s:02d}s" if h else f"{m}m {s:02d}s"


# Read the CSV text into a list of dictionaries with title, seconds and views.
def load(csv_text: str) -> list:
    rows = []
    for r in csv.DictReader(io.StringIO(csv_text)):
        rows.append({"title": r["title"].strip(), "secs": parse_duration(r["duration"]),
                     "views": int(r.get("views") or 0)})
    return rows


# Greedy study planner: keep adding videos to a day until the next one would exceed the daily budget.
def plan(videos: list, minutes_per_day: int) -> list:
    # Videos are never split and stay in order.
    """Greedy in-order packing. A video longer than the budget gets a day to itself."""
    # cap = daily budget in seconds; days = finished days; cur = today's videos; used = seconds so far.
    cap, days, cur, used = minutes_per_day * 60, [], [], 0
    for v in videos:
        # Budget would overflow: close the current day and start a new one.
        if cur and used + v["secs"] > cap:
            days.append(cur)
            cur, used = [], 0
        cur.append(v)
        used += v["secs"]
    # Don't forget the last, partially filled day.
    if cur:
        days.append(cur)
    return days


# Statistics: total/average time, longest, shortest and the five most-viewed videos.
def summary(videos: list) -> dict:
    total = sum(v["secs"] for v in videos)
    return {"count": len(videos), "total": total, "average": total // len(videos),
            "longest": max(videos, key=lambda v: v["secs"]), "shortest": min(videos, key=lambda v: v["secs"]),
            "top_viewed": sorted(videos, key=lambda v: -v["views"])[:5]}


# Generate a repeatable sample playlist (101 videos) for the demo.
def sample_csv(n: int = 101, seed: int = 11) -> str:
    rng = random.Random(seed)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["title", "duration", "views"])
    for i in range(1, n + 1):
        # Random duration 8-45 minutes and random view count.
        w.writerow([f"Python in Telugu - Part {i}", fmt_csv(rng.randint(480, 2700)), rng.randint(500, 90000)])
    return out.getvalue()


# Format seconds as M:SS for the CSV file.
def fmt_csv(secs: int) -> str:
    return f"{secs // 60}:{secs % 60:02d}"


# Print the report and return the data so the demo can check it.
def report(csv_text: str, minutes_per_day: int):
    videos = load(csv_text)
    s, days = summary(videos), plan(videos, minutes_per_day)
    print(f"Videos: {s['count']}   Total: {fmt(s['total'])}   Average: {fmt(s['average'])}")
    print(f"Longest : {s['longest']['title']} ({fmt(s['longest']['secs'])})")
    print(f"Shortest: {s['shortest']['title']} ({fmt(s['shortest']['secs'])})")
    print(f"Plan at {minutes_per_day} min/day -> {len(days)} days")
    # Show the first three days of the plan as a preview.
    for i, d in enumerate(days[:3], 1):
        print(f"  Day {i}: {len(d)} videos, {fmt(sum(v['secs'] for v in d))}")
    return videos, s, days


# Demo with assertions.
def demo() -> None:
    videos, s, days = report(sample_csv(), 60)
    assert len(videos) == 101
    # Nothing lost: the planned time equals the total playlist time.
    assert sum(sum(v["secs"] for v in d) for d in days) == s["total"]       # nothing lost
    # Order preserved: flattening the days gives the original list.
    assert [v for d in days for v in d] == videos                            # order preserved
    # A plan can never use fewer days than total time / daily budget (ceiling division with -(-a // b)).
    assert len(days) >= -(-s["total"] // 3600)                               # cannot beat the lower bound
    # No day exceeds the budget unless it holds a single over-long video.
    assert all(sum(v["secs"] for v in d) <= 3600 or len(d) == 1 for d in days)
    # Check all three accepted duration formats.
    assert parse_duration("1:02:03") == 3723 and parse_duration("12:30") == 750 and parse_duration("45") == 45
    # Invalid text must raise ValueError.
    try:
        parse_duration("abc"); raise AssertionError
    except ValueError:
        pass
    print("PythonLife playlist analyzer demo OK")


# CLI: pass a CSV path (and optionally --minutes-per-day); with no arguments run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        mins = int(sys.argv[sys.argv.index("--minutes-per-day") + 1]) if "--minutes-per-day" in sys.argv else 60
        with open(sys.argv[1], encoding="utf-8") as f:
            report(f.read(), mins)
    else:
        demo()
