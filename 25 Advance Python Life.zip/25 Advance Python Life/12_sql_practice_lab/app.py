#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 12 - Oracle-style SQL Practice Lab
=====================================================
WHAT IT DOES
    A safe playground to practise SQL. Students type SELECT queries (even with
    Oracle habits: NVL, DECODE, SYSDATE, FROM DUAL, FETCH FIRST n ROWS ONLY) and
    the lab grades them by comparing result sets with the reference answer.
    SQLite's authorizer blocks everything except reading, and a progress handler
    kills runaway queries.

WHAT YOU LEARN
    sqlite3 authorizer + progress handler (security), registering Python functions
    as SQL functions, regex-based SQL translation, result-set comparison.
    (Oracle compatibility here is a learning shim, not a full Oracle emulator.)

USAGE
    python app.py            # demo with assertions
    python app.py --shell    # interactive: type queries, ':ex' lists exercises
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# re rewrites Oracle syntax, sqlite3 is the database engine.
import re
import sqlite3
import sys

# Seed data loaded into an in-memory database on start-up.
# The one-row table DUAL mimics Oracle's dummy table (SELECT 1 FROM dual).
SEED = """
CREATE TABLE courses(id INTEGER PRIMARY KEY, title TEXT, fee INTEGER);
CREATE TABLE students(id INTEGER PRIMARY KEY, name TEXT, city TEXT);
CREATE TABLE enrollments(student_id INTEGER, course_id INTEGER, grade TEXT);
CREATE TABLE dual(dummy TEXT);
INSERT INTO dual VALUES('X');
INSERT INTO courses VALUES (1,'Python',10000),(2,'Oracle SQL',8000),(3,'Java',12000);
INSERT INTO students VALUES (1,'Ravi','Hyderabad'),(2,'Sita','Vijayawada'),(3,'Anil',NULL),(4,'Meena','Hyderabad');
INSERT INTO enrollments VALUES (1,1,'A'),(1,2,'B'),(2,1,'A'),(3,3,NULL),(4,2,'A');
"""

# Practice exercises: a prompt for the student and a reference solution the lab uses for grading.
EXERCISES = [
    {"id": 1, "prompt": "List student names in Hyderabad.",
     "solution": "SELECT name FROM students WHERE city = 'Hyderabad'"},
    {"id": 2, "prompt": "Show each student's name and city, replacing missing city with 'Unknown'.",
     "solution": "SELECT name, IFNULL(city, 'Unknown') FROM students"},
    {"id": 3, "prompt": "Number of enrollments per course title, most popular first.",
     "solution": "SELECT c.title, COUNT(*) AS n FROM courses c JOIN enrollments e ON e.course_id = c.id "
                 "GROUP BY c.title ORDER BY n DESC, c.title"},
    {"id": 4, "prompt": "The two most expensive courses (title only), dearest first.",
     "solution": "SELECT title FROM courses ORDER BY fee DESC LIMIT 2"},
]

# Allow-list for SQLite's authorizer. Only reading is permitted: SELECT statements, reading
# columns, functions and recursive CTEs. Everything else (INSERT, DROP, ...) is denied.
ALLOWED = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION, getattr(sqlite3, "SQLITE_RECURSIVE", 33)}


# Python implementation of Oracle's DECODE(expr, search, result, ..., default).
def _decode(expr, *rest):
    """Oracle DECODE(expr, search1, result1, ..., [default])."""
    # Split the arguments into (search, result) pairs and an optional trailing default.
    pairs, default = rest[: len(rest) // 2 * 2], (rest[-1] if len(rest) % 2 else None)
    for i in range(0, len(pairs), 2):
        if expr == pairs[i]:
            return pairs[i + 1]
    return default


# Rewrite a few Oracle-only constructs so SQLite understands them.
def translate(sql: str) -> str:
    """Rewrite a few Oracle-only constructs into SQLite equivalents."""
    # FETCH FIRST n ROWS ONLY -> LIMIT n.
    sql = re.sub(r"\bFETCH\s+FIRST\s+(\d+)\s+ROWS?\s+ONLY\b", r"LIMIT \1", sql, flags=re.I)
    # SYSDATE -> date('now').
    sql = re.sub(r"\bSYSDATE\b", "date('now')", sql, flags=re.I)
    # Remove surrounding whitespace and a trailing semicolon.
    return sql.strip().rstrip(";")


# The practice lab: a sandboxed in-memory database plus grading.
class Lab:
    def __init__(self, max_steps: int = 200_000):
        self.con = sqlite3.connect(":memory:")
        self.con.executescript(SEED)
        # Register Oracle functions NVL and DECODE (-1 = any number of arguments).
        self.con.create_function("NVL", 2, lambda a, b: b if a is None else a)
        self.con.create_function("DECODE", -1, _decode)
        # Maximum virtual-machine steps allowed before a query is killed.
        self.max_steps = max_steps

    # Run one read-only query safely.
    def query(self, sql: str) -> list:
        steps = {"n": 0}

        # Progress handler: SQLite calls it every 1000 VM instructions.
        def guard():                         # called every 1000 VM instructions
            steps["n"] += 1000
            # Returning 1 tells SQLite to abort the query (raises OperationalError: interrupted).
            return 1 if steps["n"] > self.max_steps else 0

        # Authorizer: allow only the safe actions listed in ALLOWED, deny everything else.
        self.con.set_authorizer(lambda action, *_: sqlite3.SQLITE_OK if action in ALLOWED else sqlite3.SQLITE_DENY)
        # Install the runaway-query guard.
        self.con.set_progress_handler(guard, 1000)
        try:
            return self.con.execute(translate(sql)).fetchall()
        # Always remove the safety hooks again, even if the query failed.
        finally:
            self.con.set_authorizer(None)
            self.con.set_progress_handler(None, 0)

    # Compare a student's query result with the reference solution's result.
    def grade(self, exercise_id: int, student_sql: str) -> tuple:
        ex = next(e for e in EXERCISES if e["id"] == exercise_id)
        want = self.query(ex["solution"])
        try:
            got = self.query(student_sql)
        except sqlite3.Error as err:
            return False, f"SQL error: {err}"
        # Order matters only if the reference solution has ORDER BY.
        ordered = "order by" in ex["solution"].lower()
        # Unordered results are compared as sorted lists, so row order does not matter.
        same = got == want if ordered else sorted(map(repr, got)) == sorted(map(repr, want))
        return (True, "Correct!") if same else (False, f"Result differs: got {len(got)} row(s), expected {len(want)}")


# Demo with assertions.
def demo() -> None:
    lab = Lab()
    assert lab.grade(1, "select name from students where city='Hyderabad';")[0]
    # Oracle's NVL works because we registered it.
    assert lab.grade(2, "SELECT name, NVL(city,'Unknown') FROM students")[0]              # Oracle NVL works
    # Oracle's FETCH FIRST is translated to LIMIT.
    assert lab.grade(4, "SELECT title FROM courses ORDER BY fee DESC FETCH FIRST 2 ROWS ONLY")[0]
    assert lab.grade(3, "SELECT c.title, COUNT(*) n FROM courses c JOIN enrollments e ON e.course_id=c.id "
                        "GROUP BY c.title ORDER BY n DESC, c.title")[0]
    # A query returning the wrong rows is marked incorrect.
    assert not lab.grade(1, "SELECT name FROM students")[0]                                  # wrong result
    # DECODE works like a CASE expression.
    assert lab.query("SELECT DECODE(city,'Hyderabad','HYD','OTHER') FROM students WHERE id=1") == [("HYD",)]
    assert lab.query("SELECT 1 FROM dual") == [(1,)]
    # Attempts to modify data must be rejected by the authorizer.
    for evil in ("DROP TABLE students", "DELETE FROM students", "INSERT INTO students VALUES (9,'x','y')"):
        ok, msg = lab.grade(1, evil)
        assert not ok and "SQL error" in msg, evil
    # The data is untouched after the attack attempts.
    assert lab.query("SELECT COUNT(*) FROM students") == [(4,)]                              # data intact
    # An endless recursive query must be interrupted by the progress handler.
    try:
        lab.query("WITH RECURSIVE r(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM r) SELECT COUNT(*) FROM r")
        raise AssertionError("runaway query should be interrupted")
    except sqlite3.OperationalError:
        pass
    print("PythonLife SQL practice lab demo OK")


# Interactive shell: type SQL, :ex lists exercises, :grade N <sql> grades an answer, :q quits.
def shell() -> None:
    lab = Lab()
    print("Tables: courses, students, enrollments, dual. Type SQL, ':ex' for exercises, ':q' to quit.")
    # Walrus operator reads a line and tests it in the loop condition.
    while (line := input("sql> ").strip()) != ":q":
        if line == ":ex":
            for e in EXERCISES:
                print(f"  {e['id']}. {e['prompt']}")
        elif line.startswith(":grade"):
            _, n, *sql = line.split(maxsplit=2)
            print(lab.grade(int(n), sql[0] if sql else ""))
        else:
            try:
                for row in lab.query(line):
                    print(row)
            except sqlite3.Error as err:
                print("error:", err)


# Entry point guard.
if __name__ == "__main__":
    shell() if "--shell" in sys.argv else demo()
