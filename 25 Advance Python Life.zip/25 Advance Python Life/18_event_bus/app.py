#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 18 - Threaded Event Bus with Retries and Dead-Letter Queue
=============================================================================
WHAT IT DOES
    A tiny message broker inside your program. Publish events like "student.enrolled";
    subscribers register with wildcard patterns ("student.*"). Worker threads deliver
    events; a handler that fails is retried with exponential backoff, and events that
    still fail go to a dead-letter list for inspection - exactly how production systems
    (Kafka consumers, SQS, Celery) behave.

WHAT YOU LEARN
    threading, queue.Queue, producer/consumer pattern, fnmatch wildcards, retry with
    exponential backoff, graceful shutdown with sentinels, decoupled architecture.

USAGE
    python app.py        # demo with assertions
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# fnmatch = wildcard topic patterns, queue = thread-safe job queue, threading = workers and locks.
import fnmatch
import queue
import threading
import time
from collections import Counter


# In-process message broker: publishers send events to topics; worker threads deliver them to subscribers.
class EventBus:
    def __init__(self, workers: int = 2, max_retries: int = 3, backoff: float = 0.01):
        # _subs holds (pattern, handler) pairs; _q is the thread-safe queue of pending events.
        self._subs: list = []
        self._q: queue.Queue = queue.Queue()
        # Protects the shared statistics and dead-letter list from simultaneous updates.
        self._lock = threading.Lock()
        self.max_retries, self.backoff = max_retries, backoff
        # stats counts published/delivered/retries; dead_letters keeps events that failed every attempt.
        self.stats, self.dead_letters = Counter(), []
        # Start the worker threads (daemon=True so they never block program exit).
        self._threads = [threading.Thread(target=self._worker, daemon=True) for _ in range(workers)]
        for t in self._threads:
            t.start()

    # Register a handler for topics matching a wildcard pattern such as "student.*".
    def subscribe(self, pattern: str, handler) -> None:
        self._subs.append((pattern, handler))

    # Publishing only enqueues the event and returns immediately.
    def publish(self, topic: str, payload: dict) -> None:
        with self._lock:
            self.stats["published"] += 1
        self._q.put((topic, payload))

    # Each worker loops forever: take an event, deliver it to every matching subscriber.
    def _worker(self) -> None:
        while True:
            item = self._q.get()
            # None is the sentinel telling a worker to stop.
            if item is None:                                   # sentinel = shut down
                self._q.task_done()
                return
            topic, payload = item
            for pattern, handler in list(self._subs):
                # fnmatchcase supports * and ? wildcards (case-sensitive).
                if fnmatch.fnmatchcase(topic, pattern):
                    self._deliver(handler, topic, payload)
            # task_done() lets close() know this event has been fully processed.
            self._q.task_done()

    # Call a handler with retries and exponential backoff.
    def _deliver(self, handler, topic, payload) -> None:
        for attempt in range(1, self.max_retries + 1):
            try:
                handler(topic, payload)
                with self._lock:
                    self.stats["delivered"] += 1
                return
            # Catch every error: a faulty handler must not kill the worker thread.
            except Exception as exc:                           # a bad handler must never kill the worker
                # Last attempt failed: move the event to the dead-letter list for later inspection.
                if attempt == self.max_retries:
                    with self._lock:
                        self.dead_letters.append({"topic": topic, "payload": payload,
                                                  "handler": handler.__name__, "error": repr(exc)})
                    return
                with self._lock:
                    self.stats["retries"] += 1
                # Exponential backoff: wait backoff, 2x backoff, 4x backoff, ... before the next try.
                time.sleep(self.backoff * 2 ** (attempt - 1))

    # Graceful shutdown: finish all queued events, then stop every worker.
    def close(self) -> None:
        """Wait for every queued event to be handled, then stop the workers."""
        # join() blocks until every queued event has been processed.
        self._q.join()
        for _ in self._threads:
            # One stop sentinel per worker.
            self._q.put(None)
        for t in self._threads:
            t.join()


# Demo with assertions.
def demo() -> None:
    bus = EventBus(workers=3)
    log, attempts, lock = [], Counter(), threading.Lock()

    # A flaky handler: fails twice (SMTP busy) and succeeds on the third attempt.
    def send_welcome_email(topic, payload):          # flaky: fails twice, then works
        with lock:
            attempts[payload["name"]] += 1
            n = attempts[payload["name"]]
        if n < 3:
            raise ConnectionError("SMTP busy")
        with lock:
            log.append(f"welcome email -> {payload['name']}")

    # A reliable handler that records every student.* event.
    def crm_sync(topic, payload):
        with lock:
            log.append(f"crm {topic} {payload['name']}")

    # A handler that always fails -> its event ends up in the dead-letter list.
    def payment_alert(topic, payload):               # always broken
        raise RuntimeError("alert service down")

    # Exact-topic and wildcard subscriptions.
    bus.subscribe("student.enrolled", send_welcome_email)
    bus.subscribe("student.*", crm_sync)
    bus.subscribe("payment.failed", payment_alert)
    # Publish four events: one for each handler plus one nobody listens to.
    bus.publish("student.enrolled", {"name": "Ravi"})
    bus.publish("student.completed", {"name": "Sita"})
    bus.publish("payment.failed", {"name": "Anil", "amount": 8000})
    bus.publish("unrelated.topic", {"name": "nobody"})
    # Wait for all deliveries to finish.
    bus.close()

    for line in sorted(log):
        print(" ", line)
    print("stats:", dict(bus.stats), "| dead letters:", bus.dead_letters)
    # Expected log: both CRM events and the welcome email (which needed retries).
    assert sorted(log) == ["crm student.completed Sita", "crm student.enrolled Ravi", "welcome email -> Ravi"]
    # The flaky handler was called exactly 3 times for Ravi.
    assert attempts["Ravi"] == 3                                  # retried until success
    # Stats: 4 published, 3 delivered, 4 retries (2 for the flaky email + 2 for the always-broken alert).
    assert bus.stats["published"] == 4 and bus.stats["delivered"] == 3 and bus.stats["retries"] == 4
    # The permanently failing alert lands in the dead-letter list.
    assert len(bus.dead_letters) == 1 and bus.dead_letters[0]["handler"] == "payment_alert"
    print("PythonLife event bus demo OK")


# Entry point guard.
if __name__ == "__main__":
    demo()
