#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 16 - Mini Static Site Generator (Markdown -> HTML)
=====================================================================
WHAT IT DOES
    Turns a folder of Markdown notes into a themed (black/orange) website with an
    auto-generated index page. Includes its OWN small Markdown converter: headings,
    paragraphs, bold/italic, inline code, fenced code blocks, lists, blockquotes and
    links - with HTML escaping and unsafe-link blocking, so pasted text cannot inject scripts.

WHAT YOU LEARN
    text parsing with a line-by-line state machine, regex substitutions, placeholder
    technique to protect code spans, front-matter parsing, pathlib file generation, XSS safety.

USAGE
    python app.py                      # demo (temp folders, assertions)
    python app.py notes_dir site_dir   # build your own site
Note files may start with front matter:
    ---
    title: My Lesson
    date: 2026-11-13
    ---
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# html.escape stops injected markup, re powers the Markdown converter, pathlib handles files.
import html
import re
import sys
import tempfile
from pathlib import Path

# Allow-list for link targets: http(s), mailto, absolute paths, #anchors and plain relative paths.
# Anything else (javascript:, data:, ...) is replaced by "#".
SAFE_URL = re.compile(r"^(https?://|mailto:|/|#|[\w.\-/]+$)", re.I)

# HTML page template (CSS braces are doubled because str.format is used) in the black/orange theme.
PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} | PythonLife</title><style>
body{{background:#111;color:#eee;font-family:Arial,sans-serif;max-width:760px;margin:40px auto;padding:0 16px;line-height:1.65}}
h1,h2,h3{{color:#ff7a00}}a{{color:#ff9f40}}pre{{background:#1d1d1d;border-left:4px solid #ff7a00;padding:12px;overflow:auto}}
code{{background:#222;padding:2px 5px;border-radius:4px}}blockquote{{border-left:4px solid #555;margin:0;padding-left:14px;color:#bbb}}
footer{{margin-top:48px;color:#888;font-size:14px}}</style></head><body>{body}<footer>Built with PythonLife Static Site Generator</footer></body></html>"""


# Convert inline Markdown (code, bold, italic, links) to HTML safely.
def inline(text: str) -> str:
    # Code spans are stashed first so Markdown characters inside them are left alone.
    codes: list = []

    # Replace each `code` with a placeholder (\x00 + index) and remember the text.
    def stash(m):
        codes.append(m.group(1))
        return f"\x00{len(codes) - 1}\x00"

    # Build a link, but only if the URL passes the allow-list.
    def link(m):
        url = m.group(2).replace('"', "%22")
        return f'<a href="{url if SAFE_URL.match(m.group(2)) else "#"}">{m.group(1)}</a>'

    # Order matters: stash code, escape HTML, then bold, italic and links.
    text = re.sub(r"`([^`]+)`", stash, text)                   # protect code first
    # Escape < > & so pasted text cannot inject tags or scripts.
    text = html.escape(text, quote=False)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Italic uses single *; the look-arounds avoid touching **bold** markers.
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<em>\1</em>", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", link, text)
    # Put the (escaped) code spans back as <code> elements.
    return re.sub(r"\x00(\d+)\x00", lambda m: f"<code>{html.escape(codes[int(m.group(1))], quote=False)}</code>", text)


# Convert a whole Markdown document to HTML, line by line.
def md_to_html(md: str) -> str:
    # para collects consecutive text lines into one paragraph.
    lines, out, para, i = md.split("\n"), [], [], 0

    # flush() closes the current paragraph.
    def flush():
        if para:
            out.append(f"<p>{inline(' '.join(para))}</p>")
            para.clear()

    while i < len(lines):
        line = lines[i]
        # Fenced code block: copy lines until the closing ``` and escape them.
        if line.startswith("```"):
            flush(); i += 1; code = []
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i]); i += 1
            out.append("<pre><code>" + html.escape("\n".join(code), quote=False) + "</code></pre>")
        # Heading: number of # characters = heading level (h1..h6).
        elif m := re.match(r"^(#{1,6})\s+(.*)", line):
            flush(); n = len(m.group(1)); out.append(f"<h{n}>{inline(m.group(2))}</h{n}>")
        # List item (- * or 1.) : gather consecutive items into one <ul>/<ol>.
        elif re.match(r"^\s*([-*]|\d+\.)\s+", line):
            flush(); ordered = bool(re.match(r"^\s*\d+\.", line)); items = []
            while i < len(lines) and re.match(r"^\s*([-*]|\d+\.)\s+", lines[i]):
                items.append("<li>" + inline(re.sub(r"^\s*([-*]|\d+\.)\s+", "", lines[i])) + "</li>"); i += 1
            tag = "ol" if ordered else "ul"
            out.append(f"<{tag}>{''.join(items)}</{tag}>"); continue
        # Block quote.
        elif line.startswith(">"):
            flush(); out.append(f"<blockquote>{inline(line.lstrip('> '))}</blockquote>")
        # A blank line ends the current paragraph.
        elif not line.strip():
            flush()
        # Ordinary text: part of the current paragraph.
        else:
            para.append(line.strip())
        i += 1
    flush()
    return "\n".join(out)


# Read optional front matter (title/date between --- lines) from the top of a note.
def split_front_matter(text: str):
    meta = {}
    if text.startswith("---\n") and "\n---\n" in text[4:]:
        head, text = text[4:].split("\n---\n", 1)
        for l in head.splitlines():
            if ":" in l:
                k, v = l.split(":", 1)
                meta[k.strip()] = v.strip()
    return meta, text


# Build the whole site: one HTML page per .md file plus an index page.
def build(src, dst) -> list:
    src, dst = Path(src), Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    posts = []
    for f in sorted(src.glob("*.md")):
        meta, body = split_front_matter(f.read_text(encoding="utf-8"))
        title = meta.get("title", f.stem.replace("-", " ").title())
        # Write the note's page (with a back link).
        (dst / f"{f.stem}.html").write_text(
            PAGE.format(title=html.escape(title), body=f'<p><a href="index.html">&larr; All notes</a></p>{md_to_html(body)}'),
            encoding="utf-8")
        posts.append({"title": title, "slug": f.stem, "date": meta.get("date", "")})
    # Newest notes first on the index page.
    posts.sort(key=lambda p: p["date"], reverse=True)
    items = "".join(f'<li><a href="{p["slug"]}.html">{html.escape(p["title"])}</a> <small>{p["date"]}</small></li>' for p in posts)
    (dst / "index.html").write_text(PAGE.format(title="Notes", body=f"<h1>PythonLife Notes</h1><ul>{items}</ul>"), encoding="utf-8")
    return posts


# Demo with assertions.
def demo() -> None:
    # Check each supported Markdown feature.
    h = md_to_html("# Title\n\nHello **bold** and *italic* with `a<b` code.\n\n- one\n- two\n\n1. first\n\n```\nprint('<x>')\n```\n> quote")
    for part in ("<h1>Title</h1>", "<strong>bold</strong>", "<em>italic</em>", "<code>a&lt;b</code>", "<ul><li>one</li><li>two</li></ul>",
                 "<ol><li>first</li></ol>", "print('&lt;x&gt;')", "<blockquote>quote</blockquote>"):
        assert part in h, part
    # Security checks: <script> is neutralised, javascript: link becomes #, a normal https link is kept.
    evil = md_to_html("<script>alert(1)</script> [click](javascript:alert(1)) [ok](https://pythonlife.in)")
    assert "<script>" not in evil and 'href="#"' in evil and 'href="https://pythonlife.in"' in evil
    # Build a real mini-site between two temporary folders.
    with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
        (Path(a) / "python-loops.md").write_text("---\ntitle: Python Loops\ndate: 2026-11-10\n---\n# Loops\nUse `for`.", encoding="utf-8")
        (Path(a) / "sql-joins.md").write_text("---\ntitle: SQL Joins\ndate: 2026-11-12\n---\n## Joins\nINNER JOIN.", encoding="utf-8")
        posts = build(a, b)
        # Index and ordering: newest note first.
        assert [p["slug"] for p in posts] == ["sql-joins", "python-loops"]          # newest first
        index = (Path(b) / "index.html").read_text(encoding="utf-8")
        assert index.index("SQL Joins") < index.index("Python Loops")
        assert "<code>for</code>" in (Path(b) / "python-loops.html").read_text(encoding="utf-8")
    print("PythonLife static site generator demo OK")


# CLI: python app.py <notes_folder> <output_folder>, or run the demo.
if __name__ == "__main__":
    if len(sys.argv) == 3:
        print(len(build(sys.argv[1], sys.argv[2])), "page(s) built")
    else:
        demo()
