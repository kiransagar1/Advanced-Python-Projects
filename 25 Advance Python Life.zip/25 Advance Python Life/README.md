# PythonLife - 25 Advanced Python Projects

Every project is a **single, well-documented `app.py`** that uses only the Python standard library
(Python 3.10+; tested on 3.12). No `pip install` needed. Each file opens with a docstring explaining
**what it does, what you learn, and how to run it**, and runs a self-checking demo (with `assert`s) by default.

```bash
python run_all.py              # runs all 25 demos, prints PASS/FAIL
cd 10_plagiarism_detector && python app.py      # run one project
```

| # | Project | Useful for | Key Python concepts |
|---|---------|-----------|---------------------|
| 01 | Student Progress Tracker | attendance, progress, at-risk alerts | sqlite3, JOINs, argparse |
| 02 | Verifiable Certificate Generator | tamper-proof SVG certificates | hmac, hashlib, SVG, escaping |
| 03 | Adaptive Quiz Engine | quizzes that adjust difficulty | dataclasses, state machine |
| 04 | Spaced Repetition Flashcards | Telugu-English glossary (SM-2) | algorithms, JSON + Unicode |
| 05 | Playlist Analyzer & Study Planner | plan 100+ video courses by daily time | csv, regex, bin-packing |
| 06 | SEO & Broken-Link Auditor | audit your HTML website folder | HTMLParser, pathlib, scoring |
| 07 | Review Sentiment Analyzer | understand student feedback (incl. Telugu-English words) | rule-based NLP, Counter |
| 08 | GST Invoice Generator | CGST/SGST/IGST invoices, amount in words (lakh/crore) | Decimal, templating |
| 09 | Batch Timetable Scheduler | clash detection, free slots, .ics calendar export | interval logic, RFC 5545 |
| 10 | Plagiarism Detector | structural code comparison | ast, shingling, Jaccard |
| 11 | Sandboxed Auto-Grader | grade Python assignments safely | subprocess, timeouts, rlimit |
| 12 | Oracle-style SQL Practice Lab | NVL/DECODE/FETCH FIRST practice, read-only sandbox | sqlite3 authorizer |
| 13 | Log Analyzer & Scanner Detector | find probes hitting your site | regex, Counter, datetime |
| 14 | Async Link Checker | concurrent website crawl | asyncio, Semaphore |
| 15 | Expense Categorizer | UPI/bank CSV to budgets & alerts | Decimal, rule engine |
| 16 | Static Site Generator | Markdown notes to a themed website | parsing, XSS-safe HTML |
| 17 | Safe Expression Engine | calculator without eval() | Pratt parser, AST |
| 18 | Event Bus | pub/sub with retries and dead-letter queue | threading, queue |
| 19 | TTL + LRU Cache Decorator | stampede-proof caching | decorators, locks, Event |
| 20 | Rate Limiter Toolkit | token bucket, sliding window, per-key limits | algorithms, DI clock |
| 21 | Course Roadmap Planner | learning order, prerequisites, weekly plan | graphs, topo sort, DP |
| 22 | Duplicate File Finder | reclaim disk space safely | hashing, streaming IO |
| 23 | Course Catalogue REST API | full CRUD API with auth and tests | http.server, REST |
| 24 | BM25 Search Engine | search notes, Telugu-aware tokenizer | inverted index, unicodedata |
| 25 | Validation Framework | mini-Pydantic with nested models | descriptors, __init_subclass__ |

## Notes
- Sample data (names, courses, fees) is illustrative - replace with your own.
- 02 uses a placeholder secret: set `PYTHONLIFE_CERT_SECRET` before issuing real certificates.
- 08 invoice details/GSTIN are placeholders; confirm tax rules with your accountant.
- 11 is a teaching-grade sandbox; for untrusted public code, add container isolation.

*PythonLife | Learn. Build. Grow.*

## License
Released under the [MIT License](LICENSE) - free to use, modify and share, including commercially,
as long as the copyright and license notice are kept. Every source file carries an SPDX header.
