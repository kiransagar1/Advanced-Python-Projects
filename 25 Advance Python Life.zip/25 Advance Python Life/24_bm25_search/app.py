#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 24 - Mini Search Engine (BM25 ranking, Telugu-aware)
=======================================================================
WHAT IT DOES
    Indexes your lecture notes / FAQs and returns the most relevant ones for a query,
    ranked with BM25 (the algorithm behind Elasticsearch/Lucene), with a highlighted
    snippet. The tokenizer uses Unicode categories, so Telugu words keep their vowel
    signs instead of being chopped up. Supports adding/removing documents and saving to JSON.

WHAT YOU LEARN
    inverted indexes, TF-IDF vs BM25 maths, unicodedata, light stemming, data
    structures for search, round-trip persistence.

USAGE
    python app.py                    # demo with assertions
    python app.py notes_folder "query words"   # search *.txt files in a folder
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# unicodedata classifies characters (so Telugu works), math.log is used by BM25, json saves the index.
import json
import math
import sys
import tempfile
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

# Stop words: very common words that carry no search value.
# Some consoles (e.g. Windows cmd/PowerShell) default to a legacy encoding that cannot print Telugu.
# Switch stdout to UTF-8 so the demo's Telugu query prints instead of crashing.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

STOP = {"a", "an", "the", "and", "or", "is", "are", "of", "to", "in", "with", "from", "all", "as", "for", "on", "by", "it"}


# Very light stemmer: "classes" -> "class", "loops" -> "loop", "running" -> "runn".
def stem(w: str) -> str:
    if len(w) > 5 and w.endswith("ing"):
        return w[:-3]
    if w.endswith("sses"):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        return w[:-1]
    return w


# Tokenizer: split text into words using Unicode categories instead of ASCII only.
# L = letters, M = combining marks (Telugu vowel signs!), N = digits - so Telugu words stay whole.
def tokenize_spans(text: str) -> list:
    """[(normalized_term, start, end)] - letters, combining marks (Telugu vowel signs) and digits form words."""
    # Return (term, start, end) so search results can highlight the original text.
    spans, i, n = [], 0, len(text)
    while i < n:
        # A word character: letter, mark or number.
        if unicodedata.category(text[i])[0] in "LMN":
            j = i
            while j < n and unicodedata.category(text[j])[0] in "LMN":
                j += 1
            # Lower-case and stem each word; skip stop words.
            term = stem(text[i:j].lower())
            if term not in STOP:
                spans.append((term, i, j))
            i = j
        else:
            i += 1
    return spans


def tokenize(text: str) -> list:
    return [t for t, _, _ in tokenize_spans(text)]


# Inverted index with BM25 ranking (the algorithm behind Lucene/Elasticsearch).
class SearchIndex:
    # k1 controls term-frequency saturation; b controls document-length normalisation.
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs: dict = {}
        # Inverted index: term -> {document id: how many times the term occurs in it}.
        self.postings: dict = defaultdict(dict)     # term -> {doc_id: term_frequency}
        self.length: dict = {}

    # Add a document (re-adding an id replaces the old version).
    def add(self, doc_id: str, text: str) -> None:
        if doc_id in self.docs:
            self.remove(doc_id)
        terms = tokenize(text)
        self.docs[doc_id], self.length[doc_id] = text, len(terms)
        for term, tf in Counter(terms).items():
            self.postings[term][doc_id] = tf

    # Remove a document from the index and clean up terms that no longer occur anywhere.
    def remove(self, doc_id: str) -> None:
        for term in [t for t, p in self.postings.items() if doc_id in p]:
            del self.postings[term][doc_id]
            if not self.postings[term]:
                del self.postings[term]
        self.docs.pop(doc_id, None)
        self.length.pop(doc_id, None)

    # Rank documents for a query and return the top k as (id, score, snippet).
    def search(self, query: str, k: int = 3) -> list:
        n = len(self.docs)
        if not n:
            return []
        # avgdl = average document length in terms.
        avgdl = sum(self.length.values()) / n or 1
        scores: dict = defaultdict(float)
        q_terms = set(tokenize(query))
        for term in q_terms:
            posting = self.postings.get(term, {})
            # IDF: rarer terms are worth more. The +1 inside log keeps it positive.
            idf = math.log(1 + (n - len(posting) + 0.5) / (len(posting) + 0.5))
            for doc, tf in posting.items():
                # Length normalisation: long documents are penalised slightly so they do not win just by size.
                norm = tf + self.k1 * (1 - self.b + self.b * self.length[doc] / avgdl)
                # BM25 term score: idf x saturated term frequency; scores of all query terms add up.
                scores[doc] += idf * tf * (self.k1 + 1) / norm
        # Best first; ties are broken alphabetically for stable output.
        ranked = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))[:k]
        return [(doc, round(s, 4), self.snippet(doc, q_terms)) for doc, s in ranked]

    # Show the text around the first matching word with the match wrapped in [brackets].
    def snippet(self, doc_id: str, q_terms: set, radius: int = 45) -> str:
        text = self.docs[doc_id]
        for term, s, e in tokenize_spans(text):
            if term in q_terms:
                lo, hi = max(0, s - radius), min(len(text), e + radius)
                return ("..." if lo else "") + text[lo:s] + "[" + text[s:e] + "]" + text[e:hi] + ("..." if hi < len(text) else "")
        return text[:2 * radius]

    # Persist the documents (not the index) as JSON; ensure_ascii=False keeps Telugu readable.
    def save(self, path) -> None:
        Path(path).write_text(json.dumps(self.docs, ensure_ascii=False), encoding="utf-8")

    # Rebuild the index by re-adding every saved document.
    @classmethod
    def load(cls, path) -> "SearchIndex":
        idx = cls()
        for doc_id, text in json.loads(Path(path).read_text(encoding="utf-8")).items():
            idx.add(doc_id, text)
        return idx


# Sample notes (English plus one Telugu/English note).
NOTES = {
    "loops": "Python loops repeat code. A for loop iterates over a list or range, while a while loop runs until a condition is false.",
    "functions": "Functions group reusable code. Define a function with def, pass arguments and return values.",
    "sql-joins": "SQL joins combine rows from two tables. INNER JOIN keeps matching rows, LEFT JOIN keeps all rows from the left table.",
    "oracle-plsql": "PL/SQL is Oracle's procedural language. Write procedures, functions and triggers with loops and exceptions.",
    "telugu-loop": "పునరావృతం అంటే loop. Python లో for loop వాడతారు.",
    "classes": "Classes bundle data and methods. Objects are instances of a class, inheritance reuses behavior.",
}


# Demo with assertions.
def demo() -> None:
    idx = SearchIndex()
    for k, v in NOTES.items():
        idx.add(k, v)
    for q in ("python loops", "while loop condition", "left join", "పునరావృతం", "classes", "procedures triggers"):
        print(f"{q!r:>22} ->", [(d, s) for d, s, _ in idx.search(q, 2)])
    # More matching query terms in a document -> higher rank.
    assert idx.search("while loop condition iterates")[0][0] == "loops"
    # The short Telugu note also contains both "python" and "loop", so it legitimately ranks too.
    assert {d for d, _, _ in idx.search("python loops", 2)} == {"loops", "telugu-loop"}     # short Telugu note matches both terms too
    assert idx.search("left join")[0][0] == "sql-joins"
    # Telugu queries work thanks to the Unicode-aware tokenizer.
    assert idx.search("పునరావృతం")[0][0] == "telugu-loop"
    # Stemming: "classes" and "class" both find the classes note.
    assert idx.search("classes")[0][0] == "classes" and idx.search("class")[0][0] == "classes"   # stemming
    assert idx.search("oracle procedures")[0][0] == "oracle-plsql"
    # No match -> empty result.
    assert idx.search("zzzz") == []
    # The snippet highlights the matching word.
    assert "[JOIN]" in idx.search("join")[0][2] or "[joins]" in idx.search("join")[0][2]
    # A Telugu word is kept as one token (vowel signs are not split off).
    assert tokenize("పునరావృతం loop") == ["పునరావృతం", "loop"]                                  # Telugu word kept whole
    # Save/load round trip must not change the results.
    before = idx.search("loops", 3)
    with tempfile.TemporaryDirectory() as tmp:
        idx.save(Path(tmp) / "i.json")
        assert SearchIndex.load(Path(tmp) / "i.json").search("loops", 3) == before
    # Removing a document updates the index; shared terms stay for other documents.
    idx.remove("loops")
    assert all(d != "loops" for d, _, _ in idx.search("loops", 5)) and "loop" in idx.postings
    print("PythonLife BM25 search demo OK")


# CLI: python app.py <folder_of_txt_files> "<query>", or run the demo.
if __name__ == "__main__":
    if len(sys.argv) == 3:
        ix = SearchIndex()
        for f in Path(sys.argv[1]).glob("*.txt"):
            ix.add(f.name, f.read_text(encoding="utf-8"))
        for doc, score, snip in ix.search(sys.argv[2], 5):
            print(f"{score:.3f}  {doc}\n       {snip}")
    else:
        demo()
