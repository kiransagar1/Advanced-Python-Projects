#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 15 - Bank/UPI Expense Categorizer & Budget Alerts
====================================================================
WHAT IT DOES
    Reads a CSV of transactions (date,description,amount), automatically assigns a
    category using ordered regex rules (UPI/Swiggy/Netflix/rent/recharge...), builds a
    month-by-category summary with exact Decimal math and warns when a category
    goes over its budget. Also lists unknown merchants so you can add new rules.

WHAT YOU LEARN
    csv, regex rule engines, Decimal for money, nested defaultdict aggregation,
    data-driven configuration (rules and budgets are plain data).

USAGE
    python app.py                    # demo with built-in sample data (assertions)
    python app.py statement.csv      # your own CSV; header must be: date,description,amount
Positive amount = money spent, negative = refund/income (ignored in expense totals).
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# csv + io read transaction text, re matches merchant names, Decimal keeps rupee amounts exact.
import csv
import io
import re
import sys
from collections import defaultdict
from decimal import Decimal

# Categorisation rules: (category, regex). The FIRST matching rule wins, so specific rules come first.
RULES = [  # first match wins - put specific rules first
    ("Food", r"swiggy|zomato|restaurant|cafe|biryani|dominos"),
    ("Groceries", r"bigbasket|dmart|grocer|blinkit|zepto"),
    ("Transport", r"uber|ola\b|rapido|metro|petrol|fuel|irctc"),
    ("Bills", r"airtel|jio|electricity|tsspdcl|broadband|recharge|water bill"),
    ("Subscriptions", r"netflix|spotify|hotstar|youtube premium|prime"),
    ("Learning", r"udemy|coursera|pythonlife|book"),
    ("Rent", r"\brent\b"),
    ("Shopping", r"amazon|flipkart|myntra"),
]
# Pre-compile every pattern once (case-insensitive) for speed.
COMPILED = [(cat, re.compile(pat, re.I)) for cat, pat in RULES]
# Monthly budget limits per category; categories without a budget are never flagged.
BUDGETS = {"Food": Decimal("3000"), "Shopping": Decimal("5000"), "Transport": Decimal("2000")}

# Sample bank/UPI statement used by the demo (date, description, amount).
SAMPLE = """date,description,amount
2026-10-02,UPI/SWIGGY/order 4411,450.50
2026-10-05,Rent to landlord,12000
2026-10-07,Airtel broadband recharge,999
2026-10-09,AMAZON PAY INDIA,3200
2026-10-12,UPI/ZOMATO/order,1800
2026-10-20,Uber trip,640
2026-10-25,Refund Amazon,-500
2026-11-01,NETFLIX.COM,649
2026-11-03,Swiggy Instamart dinner,2900.75
2026-11-04,Swiggy biryani,350
2026-11-10,Unknown Merchant XYZ,775.25
"""


# Return the first category whose pattern matches the description, otherwise "Uncategorized".
def categorize(description: str) -> str:
    for cat, rx in COMPILED:
        if rx.search(description):
            return cat
    return "Uncategorized"


# Build {month: {category: total}} and a list of merchants we could not categorise.
def summarize(csv_text: str) -> dict:
    # Nested defaultdict: missing months/categories start at Decimal(0) automatically.
    by_month = defaultdict(lambda: defaultdict(Decimal))
    unknown = []
    for row in csv.DictReader(io.StringIO(csv_text)):
        # Decimal(text) parses the amount exactly, with no floating-point error.
        amount = Decimal(row["amount"].strip())
        if amount <= 0:
            # Refunds and income (zero or negative amounts) are not expenses.
            continue                                   # refunds/income are not expenses
        cat = categorize(row["description"])
        # row["date"][:7] is the "YYYY-MM" month key.
        by_month[row["date"][:7]][cat] += amount
        if cat == "Uncategorized":
            unknown.append(row["description"])
    return {"months": {m: dict(c) for m, c in sorted(by_month.items())}, "unknown": unknown}


# Compare each month's category total with its budget and describe every overspend.
def alerts(summary: dict) -> list:
    out = []
    for month, cats in summary["months"].items():
        for cat, spent in cats.items():
            limit = BUDGETS.get(cat)
            if limit and spent > limit:
                out.append(f"{month} {cat}: spent {spent} > budget {limit} (over by {spent - limit})")
    return out


# Print totals per month (biggest category first), then alerts and unknown merchants.
def print_summary(s: dict) -> None:
    for month, cats in s["months"].items():
        print(f"\n{month}  total {sum(cats.values())}")
        for cat, amt in sorted(cats.items(), key=lambda kv: -kv[1]):
            print(f"  {cat:<14}{amt:>10}")
    for a in alerts(s):
        print("ALERT:", a)
    if s["unknown"]:
        print("Add rules for:", s["unknown"])


# Demo with assertions.
def demo() -> None:
    # Individual rule checks.
    assert categorize("UPI/SWIGGY/xyz") == "Food" and categorize("Ola cabs") == "Transport"
    assert categorize("Monthly rent") == "Rent" and categorize("random shop") == "Uncategorized"
    s = summarize(SAMPLE)
    print_summary(s)
    # October food = 450.50 + 1800.00.
    assert s["months"]["2026-10"]["Food"] == Decimal("2250.50")
    # The -500 refund is ignored, so shopping stays at 3200.
    assert s["months"]["2026-10"]["Shopping"] == Decimal("3200")           # refund ignored
    # November food = 2900.75 + 350.00 (Swiggy Instamart and Swiggy biryani).
    assert s["months"]["2026-11"]["Food"] == Decimal("3250.75")
    # The unrecognised merchant is listed so you can add a rule for it.
    assert s["unknown"] == ["Unknown Merchant XYZ"]
    # Only November food exceeds its 3000 budget (by 250.75).
    a = alerts(s)
    assert len(a) == 1 and "2026-11 Food" in a[0] and "250.75" in a[0]
    print("\nPythonLife expense categorizer demo OK")


# CLI: pass a CSV statement path, or run the demo.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as f:
            print_summary(summarize(f.read()))
    else:
        demo()
