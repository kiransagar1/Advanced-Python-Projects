#!/usr/bin/env python3
# PythonLife
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 PythonLife
"""
PythonLife Project 22 - Duplicate File Finder & Safe Cleaner
============================================================
WHAT IT DOES
    Finds identical files (same content, any name) in a folder tree - recorded class
    videos, repeated downloads, copied assignments - and reports how much disk space is
    wasted. It never deletes: "clean" MOVES extra copies into a quarantine folder, and
    runs in dry-run mode unless you pass --apply.

WHAT YOU LEARN
    efficient multi-stage filtering (size -> first 4 KB hash -> full SHA-256), streaming
    big files in chunks, pathlib/os.walk, shutil, designing safe destructive tools.

USAGE
    python app.py                          # demo with assertions
    python app.py folder                   # report duplicates
    python app.py folder --clean quarantine_dir [--apply]
"""
# Postponed evaluation of annotations.
from __future__ import annotations

# hashlib fingerprints file contents, os.walk scans folders, shutil moves files, tempfile hosts the demo.
import hashlib
import os
import shutil
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

# Read files in 1 MB chunks so even huge videos never have to fit in memory.
CHUNK = 1024 * 1024


# SHA-256 fingerprint of a file; `limit` hashes only the first N bytes (used as a cheap pre-check).
def hash_file(path: Path, limit: int | None = None) -> str:
    h, remaining = hashlib.sha256(), limit
    with open(path, "rb") as f:
        while True:
            # Read at most `remaining` bytes when a limit is set.
            n = CHUNK if remaining is None else min(CHUNK, remaining)
            block = f.read(n)
            # Empty read = end of file.
            if not block:
                break
            h.update(block)
            if remaining is not None:
                remaining -= len(block)
                if remaining <= 0:
                    break
    return h.hexdigest()


# Group paths by a key function and keep only groups with 2+ members (potential duplicates).
def _group(paths, key) -> list:
    buckets = defaultdict(list)
    for p in paths:
        try:
            buckets[key(p)].append(p)
        except OSError:
            # Unreadable files (permissions, vanished files) are skipped rather than crashing the scan.
            pass                                      # unreadable file: skip it
    return [g for g in buckets.values() if len(g) > 1]


# Three-stage filter: each stage is more expensive, but runs only on the files that survived the previous one.
def find_duplicates(root) -> list:
    """Return groups (lists of Paths) of files with identical content."""
    # Collect every file under the folder, recursively.
    files = [Path(d) / f for d, _, names in os.walk(root) for f in names]
    # Skip directories, symlinks and empty files (all empty files are "identical" but worthless to remove).
    files = [p for p in files if p.is_file() and not p.is_symlink() and p.stat().st_size > 0]
    # Stage 1: group by file size (just a metadata lookup).
    groups = _group(files, lambda p: p.stat().st_size)                       # stage 1: cheap
    # Stage 2: among same-size files, compare a hash of the first 4 KB.
    groups = [g2 for g in groups for g2 in _group(g, lambda p: hash_file(p, 4096))]   # stage 2: first 4 KB
    # Stage 3: for the rest, hash the full content - only these are true duplicates.
    groups = [g2 for g in groups for g2 in _group(g, hash_file)]                      # stage 3: full content
    # Sort for stable output: shortest path first inside each group, groups ordered by first path.
    return sorted((sorted(g, key=lambda p: (len(str(p)), str(p))) for g in groups), key=lambda g: str(g[0]))


# Space that could be reclaimed: one copy of each group is kept, the extra copies are wasted.
def wasted_bytes(groups: list) -> int:
    return sum(g[0].stat().st_size * (len(g) - 1) for g in groups)


# Safe clean-up: never deletes. Keeps the first file of each group and MOVES the others into a quarantine folder.
def quarantine(groups: list, dest, dry_run: bool = True) -> list:
    """Keep the first file of each group, move the rest to `dest`. Returns the moved paths."""
    dest, moved = Path(dest), []
    for gi, g in enumerate(groups):
        for p in g[1:]:
            target = dest / f"{gi:03d}_{p.name}"
            # dry_run=True (the default) only reports what would move.
            if not dry_run:
                dest.mkdir(parents=True, exist_ok=True)
                shutil.move(str(p), str(target))
            moved.append(p)
    return moved


# Demo with assertions, using a temporary folder.
def demo() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "videos"
        (root / "sub").mkdir(parents=True)
        (root / "a.txt").write_text("hello")
        # Duplicate of a.txt in another folder.
        (root / "sub" / "b.txt").write_text("hello")                          # duplicate of a.txt (other folder/name)
        # Same size as a.txt but different content - must NOT be flagged.
        (root / "c.txt").write_text("world")                                  # same size as a.txt, different content
        # Two identical 10 KB files and a third differing only in the very last byte.
        big = b"x" * 10_000
        (root / "big1.bin").write_bytes(big)
        (root / "big2.bin").write_bytes(big)
        # Stages 1 and 2 cannot tell big3 apart (same size, same first 4 KB); the full hash does.
        (root / "big3.bin").write_bytes(big[:-1] + b"y")                      # differs only in the LAST byte
        (root / "empty1").write_bytes(b"")
        (root / "empty2").write_bytes(b"")                                    # empty files are ignored
        # Only the genuine duplicates are reported.
        groups = find_duplicates(root)
        names = [sorted(p.name for p in g) for g in groups]
        print("duplicate groups:", names, "| wasted bytes:", wasted_bytes(groups))
        assert names == [["a.txt", "b.txt"], ["big1.bin", "big2.bin"]]
        # Wasted space = 5 bytes (b.txt) + 10,000 bytes (big2.bin).
        assert wasted_bytes(groups) == 5 + 10_000
        before = sorted(p.name for p in root.rglob("*") if p.is_file())
        # Dry run lists two files to move but touches nothing.
        assert len(quarantine(groups, Path(tmp) / "q", dry_run=True)) == 2     # dry run: only reports
        assert before == sorted(p.name for p in root.rglob("*") if p.is_file())
        # Real run: the extra copies are moved into the quarantine folder.
        quarantine(groups, Path(tmp) / "q", dry_run=False)
        assert len(list((Path(tmp) / "q").iterdir())) == 2
        # Afterwards no duplicates remain.
        assert find_duplicates(root) == []
    print("PythonLife duplicate finder demo OK")


# CLI: python app.py <folder> [--clean <quarantine_dir> [--apply]]. Without --apply nothing is moved.
if __name__ == "__main__":
    if len(sys.argv) > 1:
        gs = find_duplicates(sys.argv[1])
        for g in gs:
            print("\n".join(map(str, g)), end="\n\n")
        print(f"{len(gs)} group(s), {wasted_bytes(gs) / 1e6:.2f} MB wasted")
        if "--clean" in sys.argv:
            moved = quarantine(gs, sys.argv[sys.argv.index("--clean") + 1], dry_run="--apply" not in sys.argv)
            print(("Moved " if "--apply" in sys.argv else "Would move ") + f"{len(moved)} file(s)")
    else:
        demo()
